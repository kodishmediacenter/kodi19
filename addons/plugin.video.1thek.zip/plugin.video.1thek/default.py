# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.video.1thek'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UCweOkPb1wVVH0Q0Tlj4a5Pw"
icon1 = "https://yt3.ggpht.com/ytc/AKedOLQ3v9GsbycKbHSr-p4WO8eCe3ncbhbTde3IFDPKEOY=s256-c-k-c0x00ffffff-no-rj"

YOUTUBE_CHANNEL_ID2=  "channel/UCqq-ovGE01ErlXakPihhKDA/playlists"
icon2 = "https://yt3.ggpht.com/TDgG3gDEow_yMqaNQtrFjK4PNe8QN6xuFGBhAIm-zcP_ZrAc3QS_IwIVIYxudkRHMxuHu09n=s256-c-k-c0x00ffffff-no-rj"

def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
   addDir(title = "1theK",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon1,)
   addDir(title = "1theK Originals",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon2,)
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
