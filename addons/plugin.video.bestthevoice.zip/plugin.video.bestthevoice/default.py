# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.video.bestthevoice'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UCBJh1lBd44OGUd5JrHZQvCQ"
icon1 = "https://yt3.ggpht.com/ytc/AAUvwngHcMd3XWwmRyALNkv6DKHry5DGICh3o2mkWGCF7g=s256-c-k-c0x00ffffff-no-rj"

YOUTUBE_CHANNEL_ID2=  "channel/UC4pTrQqndbuz1XxGyp_i6Zg"
icon2 = "https://yt3.ggpht.com/ytc/AAUvwnhWpptdIsAKms7YsX5bgeg202KEC-ysM57HpHTP=s256-c-k-c0x00ffffff-no-rj"

YOUTUBE_CHANNEL_ID3=  "channel/UCJYtYkiGldqX6Ne938j-k2g"
icon3 = "https://yt3.ggpht.com/ytc/AAUvwniVt-_qYI4P42pwZlkt0NBzp1zpm_34D3Te53L4OA=s256-c-k-c0x00ffffff-no-rj"

def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
   addDir(title = "Best of The Voice",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon1,)
   addDir(title = "Best of The Voice Kids",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon2,)
   addDir(title = "The Voice Global",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail = icon3,)
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
