# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvif.com/retrotv/retrotv/chunklist_w1538682065.m3u8"


xbmc.Player().play(url)