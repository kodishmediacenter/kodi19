# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://59f2354c05961.streamlock.net:1443/tvdigitalbirigui/_definst_/tvdigitalbirigui/chunklist_w1124849528.m3u8"


xbmc.Player().play(url)