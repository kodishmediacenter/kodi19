# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv4.zcast.com.br/tvrecordacoeswebce/tvrecordacoeswebce/chunklist_w1407337361.m3u8"


xbmc.Player().play(url)