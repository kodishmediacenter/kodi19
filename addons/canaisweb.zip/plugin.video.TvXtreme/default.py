# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.voxtvhd.com.br/xtremetv/xtremetv/chunklist_w1393579013.m3u8"


xbmc.Player().play(url)