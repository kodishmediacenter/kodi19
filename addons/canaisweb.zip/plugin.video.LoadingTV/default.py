# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv.video.expressolider.com.br/loadingtv/loadingtv/chunklist_w1369846081.m3u8"


xbmc.Player().play(url)