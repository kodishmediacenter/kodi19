# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://video01.kshost.com.br:4443/murilo9207/murilo9207/chunklist_w523216937.m3u8"


xbmc.Player().play(url)