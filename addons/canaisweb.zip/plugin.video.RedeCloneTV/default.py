# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv5.zcast.com.br/redeclonetv/redeclonetv/chunklist_w1793759360.m3u8"


xbmc.Player().play(url)