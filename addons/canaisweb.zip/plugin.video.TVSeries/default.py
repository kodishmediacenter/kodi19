# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvif.com/tvserie2/tvserie2/chunklist_w26024374.m3u8"


xbmc.Player().play(url)