# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://edge1o.live.opencaster.com/caster/ewrsoDoGuhkx.m3u8"


xbmc.Player().play(url)