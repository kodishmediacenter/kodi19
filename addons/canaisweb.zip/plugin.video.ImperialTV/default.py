# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://5eaa6849d0971.streamlock.net/tvimperialnet/tvimperialnet/chunklist_w886409549.m3u8"


xbmc.Player().play(url)