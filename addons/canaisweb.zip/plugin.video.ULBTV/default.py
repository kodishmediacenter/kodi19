# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv1.zcast.com.br/ulbtv/ulbtv/chunklist_w890460208.m3u8"


xbmc.Player().play(url)