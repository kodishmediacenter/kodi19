# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv5.zcast.com.br/tvmaisbrasil/tvmaisbrasil/chunklist_w1682238439.m3u8"


xbmc.Player().play(url)