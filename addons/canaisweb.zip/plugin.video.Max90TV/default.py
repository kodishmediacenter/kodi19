# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://alanza.iptv2022.com/TV_MAX_90/tracks-v1a1/mono.m3u8"


xbmc.Player().play(url)