# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stream01.msolutionbrasil.com.br/hls/conectv/live.m3u8"


xbmc.Player().play(url)