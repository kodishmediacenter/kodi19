# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://streaming03.zas.media:1936/tvfuturo/tvfuturo/chunklist_w1161483873.m3u8"


xbmc.Player().play(url)