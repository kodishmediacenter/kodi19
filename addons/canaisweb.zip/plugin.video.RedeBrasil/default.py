# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://59f2354c05961.streamlock.net:1443/rbtv/_definst_/rbtv/chunklist_w107838109.m3u8"


xbmc.Player().play(url)