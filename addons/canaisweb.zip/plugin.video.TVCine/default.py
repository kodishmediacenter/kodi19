# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv2.zcast.com.br/elzemar/elzemar/chunklist_w44162996.m3u8"


xbmc.Player().play(url)