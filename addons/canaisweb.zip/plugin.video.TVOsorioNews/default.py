# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvstm.com/demo2573/demo2573/chunklist_w229681767.m3u8"


xbmc.Player().play(url)