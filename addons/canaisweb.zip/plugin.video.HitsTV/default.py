# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://strv1.estbrasil.com/hitstv/hitstv/chunklist_w2079897566.m3u8"


xbmc.Player().play(url)