# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stream.ads.ottera.tv/cl/e839bf53-17d0-4285-86eb-6f23d108f9b1/1280x720_3071200_0_false.m3u8"


xbmc.Player().play(url)