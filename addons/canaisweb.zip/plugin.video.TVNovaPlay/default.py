# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv4.zcast.com.br/tvnovaplay/tvnovaplay/chunklist_w908923275.m3u8"


xbmc.Player().play(url)