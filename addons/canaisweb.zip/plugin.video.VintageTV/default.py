# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvif.com/webvintage/webvintage/chunklist_w2047868114.m3u8"


xbmc.Player().play(url)