# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://tv01.livemustv.com.br/livemustv1358/livemustv1358/chunklist_w1073079000.m3u8"


xbmc.Player().play(url)