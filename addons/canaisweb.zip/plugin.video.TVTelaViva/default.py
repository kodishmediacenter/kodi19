# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv4.zcast.com.br/telavivatv/telavivatv/chunklist_w1502623473.m3u8"


xbmc.Player().play(url)