# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://596639ebdd89b.streamlock.net/8072/8072/chunklist_w1714776297.m3u8"


xbmc.Player().play(url)