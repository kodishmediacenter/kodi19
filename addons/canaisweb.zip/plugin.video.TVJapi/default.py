# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv2.zcast.com.br/tvjapi/tvjapi/chunklist_w898823386.m3u8"


xbmc.Player().play(url)