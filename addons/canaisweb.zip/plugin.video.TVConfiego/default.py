# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.voxtvhd.com.br/tvconfiegogospel/tvconfiegogospel/chunklist_w1747432215.m3u8"


xbmc.Player().play(url)