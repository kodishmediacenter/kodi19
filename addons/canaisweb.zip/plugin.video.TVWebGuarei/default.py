# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvif.com/radiowebguarei/radiowebguarei/chunklist_w1981731542.m3u8"


xbmc.Player().play(url)