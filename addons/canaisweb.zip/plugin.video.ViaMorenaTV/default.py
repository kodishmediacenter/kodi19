# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://5ad482a77183d.streamlock.net/cleuzaviamorena.com/cleuzaviamorena.com/chunklist_w82374085.m3u8"


xbmc.Player().play(url)