# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv3.zcast.com.br/leonardo2328/leonardo2328/chunklist_w1638274806.m3u8"


xbmc.Player().play(url)