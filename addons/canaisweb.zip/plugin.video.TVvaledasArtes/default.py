# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://59f1cbe63db89.streamlock.net:1443/tvvaledasartes/_definst_/tvvaledasartes/chunklist_w705971089.m3u8"


xbmc.Player().play(url)