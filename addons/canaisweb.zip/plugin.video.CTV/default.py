# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://5eaa6849d0971.streamlock.net/ctvpb/ctvpb/chunklist_w311481941.m3u8"


xbmc.Player().play(url)