# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv.video.expressolider.com.br/loadingtv/loadingtv/chunklist_w1674127793.m3u8"


xbmc.Player().play(url)