# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv4.zcast.com.br/redetvoficial/redetvoficial/chunklist_w1748841458.m3u8"


xbmc.Player().play(url)