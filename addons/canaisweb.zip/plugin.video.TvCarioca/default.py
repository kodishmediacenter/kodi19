# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv5.zcast.com.br/tvcarioca/tvcarioca/chunklist_w1359426879.m3u8"


xbmc.Player().play(url)