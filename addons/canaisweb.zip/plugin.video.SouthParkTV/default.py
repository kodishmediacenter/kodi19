# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "http://service-stitcher.clusters.pluto.tv/stitch/hls/channel/609ae66b359b270007869ff1/master.m3u8?advertisingId=&appName=web&appVersion=unknown&appStoreUrl=&architecture=&buildVersion=&clientTime=0&deviceDNT=0&deviceId=c1c53920-1b34-11ec-b13b-f726df667295&deviceMake=Chrome&deviceModel=web&deviceType=web&deviceVersion=unknown&includeExtendedEvents=false&sid=b653f9b6-9c4f-4434-acae-e507f4a366eb&userId=&serverSideAds=true"


xbmc.Player().play(url)