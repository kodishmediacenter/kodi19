# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvif.com/canal29/canal29/chunklist_w1946540340.m3u8"


xbmc.Player().play(url)