# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.caillou'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')
base    = 'plugin://plugin.video.youtube/'

def addDir(title, url):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':ICON,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
if __name__ == '__main__':
    addDir(title = "Caillou 1º Temp"             , url = base + "playlist/PLNu1vy5jyfy8sh1utuPPN09uYnsBuTMVr/",)
    addDir(title = "Caillou 2º Temp"             , url = base + "playlist/PLNu1vy5jyfy_dS3zAZbihW4Etg3ISe6Ma/",)
    addDir(title = "Caillou 3º Temp"             , url = base + "playlist/PLNu1vy5jyfy9YUHDSSZwlHhCe0oXvLWPw/",)
    addDir(title = "Caillou 4º Temp"             , url = base + "playlist/PLNu1vy5jyfy_RAr9Z8BMMjH--GE_7sKdS/",)
    addDir(title = "Caillou Especiais"            ,url = base + "playlist/PLgGs0j7UlMwiL1ltRijidE_sKgKnCFYRg/",)
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)

