# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.video.FlowPodcast'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UC4ncvgh5hFr5O83MH7-jRJg"
YOUTUBE_CHANNEL_ID2=  "channel/UC3uYvpJ3J6oNoNYRXfZXjEw"
YOUTUBE_CHANNEL_ID3=  "channel/UCopNlF81S59R5sE2jYxGz2A"
YOUTUBE_CHANNEL_ID4=  "channel/UC_vCmODMFq9pYyiY2wZVsIQ"


icon1 = "https://yt3.ggpht.com/ytc/AAUvwnh3qcXoKDGfaEE_tqvBu-VCHcUg0lEPXjBNFT4rgA=s256-c-k-c0x00ffffff-no-rj"
def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
   addDir(title = "Flow Podcast",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon1,)
   addDir(title = "Cortes do Flow [OFICIAL]",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon1,)
   addDir(title = "Aquele Flau [OFICIAL]",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail = icon1,)
   addDir(title = "Flow Poop [OFICIAL]",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",thumbnail = icon1,)
   
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
