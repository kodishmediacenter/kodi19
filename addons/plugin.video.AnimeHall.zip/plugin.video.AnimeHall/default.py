# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.video.AnimeHall'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_playlist_ID_1 = "PLSyCRkPeE-W3O-tC_Ra1skkbKRgAH_TEa"    
YOUTUBE_playlist_ID_2 = "PLDTKMv24gJzSsauDtn-sUOMEd9eVhMbuP"   
YOUTUBE_playlist_ID_3 = "PL6X1o0kPTW4IG3iRHzr9ueHWbrIU-JdmB"    
YOUTUBE_playlist_ID_4 = "PLSdxKqaWodA_un0xvLCmbBJpAwabI_ULs"    
YOUTUBE_playlist_ID_5 = "PLtVHSclE6FFrKxd1vZlN8UxBqEfVv2DQz"    
YOUTUBE_playlist_ID_6 = "PLhQmEmDwD1az34wcN65lmObpyxdrS_fTW"    
YOUTUBE_playlist_ID_7 = "PL7TCEP908LDpPP2WgQsZfni1q8Zlmy8H3"    
YOUTUBE_playlist_ID_8 = "PL_0thy1yfBsittSXUZ--8gEDvu5Yqtgf9"    
YOUTUBE_playlist_ID_9 = "PLylO5ejGS8ADh-ZiOUADjjtJ7l-Tlw1rW"    
YOUTUBE_playlist_ID_10 = "PLGbBuikY0YkEYs8nB4na5bMyM0VvnPUi3"   
YOUTUBE_playlist_ID_11 = "PLoCvEtDRoYrbXOeGwU-pI63Ag40BXP864"   
YOUTUBE_playlist_ID_12 = "PL4qxzrCoZ3pJOwqroryR9WlpdZmej_PjU"   
YOUTUBE_playlist_ID_13 = "PLVk-vmCp1xOPT_zHZna0lnPsN6aSebHl3"   
YOUTUBE_playlist_ID_14 = "PLkjMasMLi9sdrZ3oRZInZriioUgM5X5U6"   
YOUTUBE_playlist_ID_15 = "PL3Khux4Dm4MA8LJQ30Lt4I4bX7YlZDp5G"   
YOUTUBE_playlist_ID_16 = "PLdQhgOSZOvIUFQPkto93pJViwpeGdQWuk"   
YOUTUBE_playlist_ID_17 = "PLaeD6aJeX-LRHPCCl3aDSyXGq2pfBuxiB"   
YOUTUBE_playlist_ID_18 = "PLhEcb9xQYyWVd_odauwBQ3b1OZu1gJ4JF"   
YOUTUBE_playlist_ID_19 = "PLHuxu11dKeVvXjciRUwt5V5oYEn3aUsfd"   
YOUTUBE_playlist_ID_20 = "PLHaDHOEwrPcLu6s8_zm7sCPyXkgKFsQDy"   
YOUTUBE_playlist_ID_21 = "PL5eW2Nx26w5jMsZ81ak2YHwx1q-i-H5uL"   
YOUTUBE_playlist_ID_22 = "PLGpxnliw4Vny4WcNUPrEpdEbZx3TLo0h1"   
YOUTUBE_playlist_ID_23 = "PLnNHbQQjTyhzq4ulFQuy9RX1dNCwCZZXh"   
YOUTUBE_playlist_ID_24 = "PLRwhzZem1iu7wkt24TWd09cVzJvHYhHre"   
YOUTUBE_playlist_ID_25 = "PL2M-O10vLUt_qMFcPv8Q8aYStmlHFDt2O"   
YOUTUBE_playlist_ID_26 = "PLggm1SEQq_iB6mIM0vi-9-OvlXZS5G_Jg"   
YOUTUBE_playlist_ID_27 = "PLqiv5It8yfq3e4H_toGgC6kwl7YfYdb_i"   
YOUTUBE_playlist_ID_28 = "PLvZYlJ1sB3boKdPXFQVf8p2HdEesV15uo"   
YOUTUBE_playlist_ID_29 = "PLIO1PuSi9qHWELxs98FbrxqR8ygRjl3lQ"  
YOUTUBE_playlist_ID_30 = "PLvBgwy26euBzinoEYZOfdYj0AwoZXVvur"   
YOUTUBE_playlist_ID_31 = "PLz6z1t7DbIQoILWIXaBSr44ULVQkuzf_X"   
YOUTUBE_playlist_ID_32 = "PLOhK_MM7Cc4tHoPRoacgt7L-JKlOB94NJ"  
YOUTUBE_playlist_ID_33 = "PLJgna3eWUtxIpSObnLzhJemue0hP34dF3"   
YOUTUBE_playlist_ID_34 = "PLqka79WXWCgO_VcSlL3dOQEJyccnwBvva"   
YOUTUBE_playlist_ID_35 = "PLUcisHsBD2Q068c3yjez3tLMUjRgJ1x30"   
YOUTUBE_playlist_ID_36 = "PLJYBnj0AIinMYXaTjlBxmk9gk1XGIA9bh"   
YOUTUBE_playlist_ID_37 = "PLGpxnliw4Vnx6uvvfThz27txI3ZpDS0ME"   
YOUTUBE_playlist_ID_38 = "PLFzeA6Lvpq8WTVnxOyVmaU7EZVMyitV2s"   
YOUTUBE_playlist_ID_39 = "PLY5wODFKkVZ4Xlwm4TzgGxsyBsx4E1voI"  
YOUTUBE_playlist_ID_40 = "PLSIVNdN-2AwbK47OiMPPXvcU1Ncy8KVRf"   
YOUTUBE_playlist_ID_41 = "PLC681AE85DF7D9FDE"   
YOUTUBE_playlist_ID_42 = "PLxvSSX84vpqe--xxoapHmGmv8dyOxvK_j"   
YOUTUBE_playlist_ID_43 = "PL5eW2Nx26w5gX1HMjAipmVHUtPdXr1W1_"   
YOUTUBE_playlist_ID_44 = "PL3tOT7t0N76TbLUjWV4NKKCCU5P-7eJw-"   
YOUTUBE_playlist_ID_45 = "PL0YC1L_o6dEjrIrYRO6FQCuTz7DLrUSVM"   
YOUTUBE_playlist_ID_46 = "PLr1ZYm5rhnhQuTStwfxAt3i0SFtOE1d_Y"   
YOUTUBE_playlist_ID_47 = "PLEtxAj9Z38nyjBkEAZ3OXulrHQktvgVP6"   
YOUTUBE_playlist_ID_48 = "PLyaa_EkSR_g83cyGRv3_Q4SlmrZqm0lpD"   
YOUTUBE_playlist_ID_49 = "PLl8_YFVLJrRV6bY-__e8tQK4plvS1y87I"   
YOUTUBE_playlist_ID_50 = "PL017FU7SY46nZ4nlgD-c8jFOYMnEej2dl"
YOUTUBE_playlist_ID_51 = "PLIO1PuSi9qHVcL5B_VWvK6l_gy2Bfz-_H"   
YOUTUBE_playlist_ID_52 = "PL3NWS1DRyJY85TPoCdh73c3Cs-hakpwGr"   
YOUTUBE_playlist_ID_53 = "PLWQSJCkN7FK8QX4RQ9A_7OyhkPQaOQNKT"   
YOUTUBE_playlist_ID_54 = "PLCR8Iya18WhM5vYe1CsL6A2TBBtfURbYj"   
YOUTUBE_playlist_ID_55 = "PLSXT4sOipmuwsXNysEGhdkgSa2jZ3ASr-"   
YOUTUBE_playlist_ID_56 = "PLSXT4sOipmuzTRcwmOkBdOwcUcCWpaoWi"   
YOUTUBE_playlist_ID_57 = "PLCcWr6nZW_pXW22AAaJw3kb7em9U_MRhJ"   
YOUTUBE_playlist_ID_58 = "PLRhZCETh6UQhHyx7inkporDJamhfmEWHR"   
YOUTUBE_playlist_ID_59 = "PLIO1PuSi9qHWO4qJPNnFh7EhQnlgk_lL-"   
YOUTUBE_playlist_ID_60 = "PLDdc2q4PrkHi8E8-6JfBFiM8jT346g590"   
YOUTUBE_playlist_ID_61 = "PLuy5ndPhad2iZl2UElI-XDWa1hR4fnOou"   
YOUTUBE_playlist_ID_62 = "PLr0Y63Ag6izMqLnJJa30XyBlktSeNXzuB"   
YOUTUBE_playlist_ID_63 = "PLFQ-OEI_mi0XO8dH1Yqq2rwcPGjUUTHDI"     
YOUTUBE_playlist_ID_65 = "PLCcWr6nZW_pVG5uTndpfL_Lgmk2w30jkH"   
YOUTUBE_playlist_ID_66 = "PLy-qmp54bpB1upS_w87xeJjgziJAw-P5D"   
YOUTUBE_playlist_ID_67 = "PLIO1PuSi9qHWFgl49j6pffzwym-w5kt2v"   
YOUTUBE_playlist_ID_68 = "PLIO1PuSi9qHUdLjA3uMjCNnvkHGbFpUXU"   
YOUTUBE_playlist_ID_69 = "PLPDEQgRNkRHfdFDkpyDRkW2QS1XEqwQwc"   
YOUTUBE_playlist_ID_70 = "PLjaJzUiR8hwnstpXhimMZDXyQcZYnFTfQ"   
YOUTUBE_playlist_ID_71 = "PLtNr7Z0qIeJnca5l5v0QabWDX479CFeGW"   
YOUTUBE_playlist_ID_72 = "PLlNbKFF5xb_c1zGig_0-E3U60_ThS3SEl"   
YOUTUBE_playlist_ID_73 = "PLyDruNPPnY28kYbFIgPvYgJwB0PadeYAd"   
YOUTUBE_playlist_ID_74 = "PLuh4O-1NwVk5u338tsG43rV80ldVYLNSN"   
YOUTUBE_playlist_ID_75 = "PL9nriNwTo0YijFh4HWoipX1F9ajB6jfYP"   
YOUTUBE_playlist_ID_76 = "PLdmW1EC5JQAqcIUDQ8vWUjSiH562hRs2Y"   
YOUTUBE_playlist_ID_77 = "PLxvSSX84vpqeh2aVr5Xj13Kf4KJbMg03a"   
YOUTUBE_playlist_ID_78 = "PLoDknc6K1GEQelB-d1f2g_SbDgq7H8Mor"   
YOUTUBE_playlist_ID_79 = "PL6SJKvYqxiCanltFuFRJ1QRtFB8IPO-Vd"   
YOUTUBE_playlist_ID_80 = "PLxmSydW1K5pS6uaZv_ZQJsMyOxXRqPrEO"   
YOUTUBE_playlist_ID_81 = "PL3NWS1DRyJY8rygUGwqC6MgW1JI7omU2A"   
YOUTUBE_playlist_ID_82 = "PLIO1PuSi9qHWO4qJPNnFh7EhQnlgk_lL-"   
YOUTUBE_playlist_ID_83 = "PLIO1PuSi9qHWez9YB5cVkX3DOQJWNRNLr"   
YOUTUBE_playlist_ID_84 = "PL2retEwks8bzDgYHcRyQh58Bo-dxrj9Rm"   
YOUTUBE_playlist_ID_85 = "PLN-d5JOQgM8ax8Zx0kQljS1pSaWIah5dv"   
YOUTUBE_playlist_ID_86 = "PLxtYLwtoxlFJiTJIndEfAOWGsmvvREnY8"   
YOUTUBE_playlist_ID_87 = "PL6WGlDXt5oogZ5EYn7relAzcqHwLyIPZ0"   
YOUTUBE_playlist_ID_88 = "PLfKXvAG2EAC-ISnvrMVZKm9birGQbR4xh"   
YOUTUBE_playlist_ID_89 = "PL2BDitArbtQjjup_hZISmtGfLreAVfwn9"   
YOUTUBE_playlist_ID_90 = "PLhoLNpXDxEdQCWEtD2LGML1AuSz5hIynW"   
YOUTUBE_playlist_ID_91 = "PL3ZbcA8oGZb8ijIWOhvy5w7_eUcCA_VIF"   
YOUTUBE_playlist_ID_92 = "PL6rNqhT4p0I2DG585WqPsSfR-ugWLk79Q"   
YOUTUBE_playlist_ID_93 = "PLXNBt-oPnRFg195C_DhQSZGVFT955GW3f"   
YOUTUBE_playlist_ID_94 = "PLM6ti43M-GpD5Nd2AQhGSjmFdAGv7PKLx"   
YOUTUBE_playlist_ID_95 = "PLB2HdLSjQcxiaUXTB3GCIXmzh5Bb1AR0d"   
YOUTUBE_playlist_ID_96 = "PLY-iZ1WEARZIGLM1fGSHVina2U7QdSxY-"   
YOUTUBE_playlist_ID_97 = "PLG-2wvu2bnmVFeC0FzMCoGc-zPoTCRiA3"   
YOUTUBE_playlist_ID_98 = "PL99xo9ydj1Up8E_2DcwLWemSl6LWQqxZV"   
YOUTUBE_playlist_ID_99 = "PLCcWr6nZW_pVJ1yshHgPPJLrwoOumCNEg"   
YOUTUBE_playlist_ID_100 = "PLYQsl_3bRnvFEwfX0TKSrhEOHOQqM08e4"   
YOUTUBE_playlist_ID_101 = "PLVchiw7oCWR4DNqmQU13fNm_Nx750kYzs"   
YOUTUBE_playlist_ID_102 = "PLdc-rPkt3NHSpaS1k-CtFFUmFWzyx8c-B"   
YOUTUBE_playlist_ID_103 = "PL3NWS1DRyJY-saVnmrUZWt1woIokKsf_T"   
YOUTUBE_playlist_ID_104 = "PLGpxnliw4VnxbPxV57zvgINmM_0t8V8eo"   
YOUTUBE_playlist_ID_105 = "PLQJWdB5is4OIgyLWciUsbulcSO5yAJihK"   
YOUTUBE_playlist_ID_106 = "PLiRWjU8XbppQ0XrIJwumzF-FEsUa976mv"   
YOUTUBE_playlist_ID_107 = "PLU6pEFSowLZYWDTqF6mSguqmAXkf-29v4"   
YOUTUBE_playlist_ID_108 = "PLueG-QLPSv_RWCDnpUEOVzKgVpP1deOHf"   
YOUTUBE_playlist_ID_109 = "PLZOC7YKS1pH2P8C4qE2dTk1ZCvgDCRsf5"   
YOUTUBE_playlist_ID_110 = "PLOsyhFozokBYkIl3OmP89h7O4Cll4RDdj"   
YOUTUBE_playlist_ID_111 = "PL4SeEQWoCs_zVtvhDMc9Iv8vj4wpr2PIG"   
YOUTUBE_playlist_ID_112 = "PLhEcb9xQYyWWsMiHF4PlwQSBEyif4fykZ"   
YOUTUBE_playlist_ID_113 = "PLLz12MlNsBZpvy_Pq4VaKDPiq_W3xfU31"   
YOUTUBE_playlist_ID_114 = "PLY9wUkhXWqMqqMI1tPW30IW1RrdZP3FEj"   
YOUTUBE_playlist_ID_115 = "PLJzzc6RdnU75gnGDb-nROERP5BPhS2o1m"   
YOUTUBE_playlist_ID_116 = "PL5eW2Nx26w5gpIcAeSVjWpEUZ1uT04wRF"   
YOUTUBE_playlist_ID_117 = "PLVZjQneW_GZNzV__heYdxkEbT1gcZjSsU"   
YOUTUBE_playlist_ID_118 = "PL5eW2Nx26w5jIBUkqscmVj8NLpQnUMNqr"   
YOUTUBE_playlist_ID_119 = "PLOPzwsZAsdIT8tENCT-TK0W_whcjzvJpJ"   
YOUTUBE_playlist_ID_120 = "PLIO1PuSi9qHVG5sBsy-8OcYVf3g7G1NM8"   
YOUTUBE_playlist_ID_121 = "PLGpxnliw4VnwL2O9-jxFJWOcJfjXWjPpA"   
YOUTUBE_playlist_ID_122 = "PLnp_hYkgulSRKXuFETWu1IxuZCKNgrAVY"   
YOUTUBE_playlist_ID_123 = "PL2Xq8qKWqCvhAFQCT6rQFYuV9r58PIqJh"   
YOUTUBE_playlist_ID_124 = "PLhEW311aTb7Gy4Tz0ly3QqHQauIN4IsIm"   
YOUTUBE_playlist_ID_125 = "PLPfJsphatmLYTN5ASKQDwk-yNKM5_opVU"   
YOUTUBE_playlist_ID_126 = "PLGpxnliw4VnyVQZY6h-aVvRX0xRSvgpIT"   
YOUTUBE_playlist_ID_127 = "PLBPY4b6-omwJQwYO4MwEjuRRq0buB8X_-" 

def addDir(title, url, thumbnail,fanart,folder):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    folder = True
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
    addDir( 
        #action="", 
        title="[COLOR aqua]AnimeHall Peliculas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1+"/",
        thumbnail="https://i.imgur.com/ZjzVE62.png",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Ace Attorney [COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_2+"/",
        thumbnail="https://i.imgur.com/zgxzGPh.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Akame Ga Kill[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_3+"/",
        thumbnail="https://i.imgur.com/O0maRtR.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Amnesia[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_4+"/",
        thumbnail="https://i.imgur.com/aukWJbt.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Ansatsu Kyosushitsu[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_5+"/",
        thumbnail="https://i.imgur.com/KxsAQbv.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Assasination Classron[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_6+"/",
        thumbnail="https://i.imgur.com/pgvQwAo.png",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Ataque A Los Titanes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_7+"/",
        thumbnail="https://i.imgur.com/QXVRkzA.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Bailando Con Vampiros[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_8+"/",
        thumbnail="https://i.imgur.com/ToxLS6u.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Bajoterra[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_9+"/",
        thumbnail="https://i.imgur.com/3vxacVI.png",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Beyblade[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_10+"/",
        thumbnail="https://i.imgur.com/740zAEm.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Blue Dragon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_11+"/",
        thumbnail="https://i.imgur.com/3EeZAcT.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Black Cat[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_12+"/",
        thumbnail="https://i.imgur.com/dPn3PY7.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Btoom[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_13+"/",
        thumbnail="https://i.imgur.com/6MXzYGf.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Chobits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_14+"/",
        thumbnail="https://i.imgur.com/0U7JbUc.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Campeones[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_15+"/",
        thumbnail="https://i.imgur.com/T6IydhL.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Cinderella Boy[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_16+"/",
        thumbnail="https://i.imgur.com/ldYggu8.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]City Hunter[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_17+"/",
        thumbnail="https://i.imgur.com/YvpyjJi.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Clannad[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_18+"/",
        thumbnail="https://i.imgur.com/kzxYYhI.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Claymore[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_19+"/",
        thumbnail="https://i.imgur.com/sg6XR1S.png",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Codigo Lyoko[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_20+"/",
        thumbnail="https://i.imgur.com/Wrd2OYr.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Corrector Yui[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_21+"/",
        thumbnail="https://i.imgur.com/JWww0fW.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Cowboy Bebop[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_22+"/",
        thumbnail="https://i.imgur.com/7uamrSQ.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Croket[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_23+"/",
        thumbnail="https://i.imgur.com/cHcbX8i.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Cross Fihgt B Daman Fireblast[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_24+"/",
        thumbnail="https://i.imgur.com/J8XmepV.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Cupid Chocolate[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_25+"/",
        thumbnail="https://i.imgur.com/73HbUe3.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Danganronpa The Animation[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_26+"/",
        thumbnail="https://i.imgur.com/eTjU7kt.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Dan Machi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_27+"/",
        thumbnail="https://i.imgur.com/zYZLVrA.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Danshi Koukoesei[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_28+"/",
        thumbnail="https://i.imgur.com/PvTfCC5.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Date A Live[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_29+"/",
        thumbnail="https://i.imgur.com/QRBSROn.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Days[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_30+"/",
        thumbnail="https://i.imgur.com/TYlAOpe.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Dead Note[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_31+"/",
        thumbnail="https://i.imgur.com/EVbKsR0.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Devil May Cry[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_32+"/",
        thumbnail="https://i.imgur.com/3gN8O1A.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Divine Gate[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_33+"/",
        thumbnail="https://i.imgur.com/JGJiEay.png",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Dna2[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_34+"/",
        thumbnail="https://i.imgur.com/38eR9Hi.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Eden Of The East[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_35+"/",
        thumbnail="https://i.imgur.com/4LgP77K.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]El Caballero Del Area[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_36+"/",
        thumbnail="https://i.imgur.com/d9QU4Bi.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Elfen Lied[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_37+"/",
        thumbnail="https://i.imgur.com/ZjVYwVy.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Espiritu De Lucha[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_38+"/",
        thumbnail="https://i.imgur.com/I1ZvqMi.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Fnafhs[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_39+"/",
        thumbnail="https://i.imgur.com/IdBc3Wa.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Full Metal Panic[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_40+"/",
        thumbnail="https://i.imgur.com/jPNTbsg.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )
		
    addDir( 
        #action="", 
        title="[COLOR aqua]Fushigi Yugi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_41+"/",
        thumbnail="https://i.imgur.com/NniVYMg.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )
		
    addDir( 
        #action="", 
        title="[COLOR aqua]Ganz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_42+"/",
        thumbnail="https://i.imgur.com/f6hqnGZ.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Gekkan Shoujo Nozaki[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_43+"/",
        thumbnail="https://i.imgur.com/AVkKaz4.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Golden Boy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_44+"/",
        thumbnail="https://i.imgur.com/3DxacXI.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Gormiti[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_45+"/",
        thumbnail="https://i.imgur.com/dlR7sZE.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Gray Man[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_46+"/",
        thumbnail="https://i.imgur.com/mQTMXl1.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Gungrave[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_47+"/",
        thumbnail="https://i.imgur.com/gw4kaKI.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Hakuchaku To Yousei[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_48+"/",
        thumbnail="https://i.imgur.com/2IpWUGN.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Hand Maid May[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_49+"/",
        thumbnail="https://i.imgur.com/DpzQPNB.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Happy Sugar Life[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_50+"/",
        thumbnail="https://i.imgur.com/kQttGOr.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Haruhi Suzumiya[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_51+"/",
        thumbnail="https://i.imgur.com/nVzcEAe.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]High School Of Dead[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_52+"/",
        thumbnail="https://i.imgur.com/l0Gx4xu.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Hungry Heart[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_53+"/",
        thumbnail="https://i.imgur.com/sXXZiAA.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Hunter X Hunter[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_54+"/",
        thumbnail="https://i.imgur.com/RxjKvma.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Inazuma Eleven[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_55+"/",
        thumbnail="https://i.imgur.com/x6sHbAz.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Inazuma Eleven Go[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_56+"/",
        thumbnail="https://i.imgur.com/Ut45BWy.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Inuyasha[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_57+"/",
        thumbnail="https://i.imgur.com/JXNqiq0.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Kaichou Wa Maid Sama[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_58+"/",
        thumbnail="https://i.imgur.com/4o2EwjE.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Kakuriyo No Yadomeshi[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_59+"/",
        thumbnail="https://i.imgur.com/GQyKK1w.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Kaleido Star[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_60+"/",
        thumbnail="https://i.imgur.com/xDd84EK.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )
	
    addDir( 
        #action="", 
        title="[COLOR aqua]Kamisama Hajimemashita[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_61+"/",
        thumbnail="https://i.imgur.com/mJvzu6q.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Kiba[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_62+"/",
        thumbnail="https://i.imgur.com/IiFZYC2.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Kill Me Baby[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_63+"/",
        thumbnail="https://i.imgur.com/7JE8Vkr.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Kobayashi San Chi No Maid Dragon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_65+"/",
        thumbnail="https://i.imgur.com/0jvnD2m.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Koi Kaze[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_66+"/",
        thumbnail="https://i.imgur.com/fJPwnkS.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Konosuba[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_67+"/",
        thumbnail="https://i.imgur.com/8nfpPzi.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Kotoura San[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_68+"/",
        thumbnail="https://i.imgur.com/nzQ4E8Z.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )
		
    addDir( 
        #action="", 
        title="[COLOR aqua]Kurokami[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_69+"/",
        thumbnail="https://i.imgur.com/SnQW4HS.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )		

    addDir( 
        #action="", 
        title="[COLOR aqua]Kyoukai No Kanata[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_70+"/",
        thumbnail="https://i.imgur.com/O5faTRt.png",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Magikano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_71+"/",
        thumbnail="https://i.imgur.com/KbK5Boj.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Mirai Nikki[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_72+"/",
        thumbnail="https://i.imgur.com/IEMhZU3.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Martin Mistery[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_73+"/",
        thumbnail="https://i.imgur.com/6W9mAKf.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Medabots[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_74+"/",
        thumbnail="https://i.imgur.com/iHVashx.png",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Mermaid Melody[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_75+"/",
        thumbnail="https://i.imgur.com/oH3pngy.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Merry Primer[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_76+"/",
        thumbnail="https://i.imgur.com/R9g1KUN.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Mononoke[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_77+"/",
        thumbnail="https://i.imgur.com/Pevhout.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Monster[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_78+"/",
        thumbnail="https://i.imgur.com/3Aoum2C.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Musaigen No Phantom[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_79+"/",
        thumbnail="https://i.imgur.com/uHBJ9BJ.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Nagi No Asukura[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_80+"/",
        thumbnail="https://i.imgur.com/n6yOv33.png",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Nana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_81+"/",
        thumbnail="https://i.imgur.com/s5zAL8q.png",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Nijiiro[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_82+"/",
        thumbnail="https://i.imgur.com/mr9w5OW.png",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Noragami Aragoto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_83+"/",
        thumbnail="https://i.imgur.com/6OgDKMc.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Nourin[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_84+"/",
        thumbnail="https://i.imgur.com/jgXU0LE.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Orange[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_85+"/",
        thumbnail="https://i.imgur.com/4MdWBtb.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Offside[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_86+"/",
        thumbnail="https://i.imgur.com/A6DiwM4.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Peliculas Anime[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_87+"/",
        thumbnail="https://i.imgur.com/3HnfnCI.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Peliculas Anime II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_88+"/",
        thumbnail="https://i.imgur.com/tFXhxiE.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Peliculas Anime III[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_89+"/",
        thumbnail="https://i.imgur.com/dfhX1zT.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )
		
    addDir( 
        #action="", 
        title="[COLOR aqua]Peliculas Anime IV[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_90+"/",
        thumbnail="https://i.imgur.com/gZV3Ha0.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Peliculas Anime V[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_91+"/",
        thumbnail="https://i.imgur.com/QkiekbL.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Peliculas Anime VI[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_92+"/",
        thumbnail="https://i.imgur.com/7QZSkJ2.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Peliculas Anime VII[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_93+"/",
        thumbnail="https://i.imgur.com/EHUOD4f.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Peliculas Anime VIII[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_94+"/",
        thumbnail="https://i.imgur.com/RvYSUkS.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Peliculas Anime IX[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_95+"/",
        thumbnail="https://i.imgur.com/8uqmu3o.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Peliculas Anime X[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_96+"/",
        thumbnail="https://i.imgur.com/bSIrsu7.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Pichi Pichi Pich[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_97+"/",
        thumbnail="https://i.imgur.com/zf4ODUp.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Rails Wars[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_98+"/",
        thumbnail="https://i.imgur.com/5ZQvhXM.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Ranma[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_99+"/",
        thumbnail="https://i.imgur.com/D0RpfDY.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Robotech[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_100+"/",
        thumbnail="https://i.imgur.com/jOsSz8H.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Rokka No Yuusha[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_101+"/",
        thumbnail="https://i.imgur.com/5IDRgQJ.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Rosario Vampire[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_102+"/",
        thumbnail="https://i.imgur.com/Hk23mNA.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Saikano[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_103+"/",
        thumbnail="https://i.imgur.com/ylHNcMs.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Sakura Card Captor[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_104+"/",
        thumbnail="https://i.imgur.com/YA0dR2h.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Samurai Shampoo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_105+"/",
        thumbnail="https://i.imgur.com/7qB80eS.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Sao Ordinal Scale[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_106+"/",
        thumbnail="https://i.imgur.com/Y2CCCpW.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Sargento Keroro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_107+"/",
        thumbnail="https://i.imgur.com/fH7yPyy.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]School Days[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_108+"/",
        thumbnail="https://i.imgur.com/3KTZuhV.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Shingeki No Kyojin[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_109+"/",
        thumbnail="https://i.imgur.com/ggaR0jI.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Slayers[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_110+"/",
        thumbnail="https://i.imgur.com/Y7BC67N.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Street Fighter II[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_111+"/",
        thumbnail="https://i.imgur.com/JJbDKir.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Sword Art Online[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_112+"/",
        thumbnail="https://i.imgur.com/E8cyxOw.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Terra Formars[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_113+"/",
        thumbnail="https://i.imgur.com/1a7rdad.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Tekkaman Blade[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_114+"/",
        thumbnail="https://i.imgur.com/fN72ik6.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]The Ancient Magus[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_115+"/",
        thumbnail="https://i.imgur.com/7A0LfCE.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Tokio Babilon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_116+"/",
        thumbnail="https://i.imgur.com/ZgtiqHu.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Tokko[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_117+"/",
        thumbnail="https://i.imgur.com/MYNXKDY.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Tokio Mew Mew[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_118+"/",
        thumbnail="https://i.imgur.com/bYpm8tA.png",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Trigun[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_119+"/",
        thumbnail="https://i.imgur.com/I9hVJ6v.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Tsurezure Children[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_120+"/",
        thumbnail="https://i.imgur.com/UOSHNio.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Vinland Saga[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_121+"/",
        thumbnail="https://i.imgur.com/3qnOopD.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Wakfu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_122+"/",
        thumbnail="https://i.imgur.com/MZCEgXC.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Watashi Ga Motete[COLOR magenta] VOSE[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_123+"/",
        thumbnail="https://i.imgur.com/4pctx75.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Wedding Peach[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_124+"/",
        thumbnail="https://i.imgur.com/0pgv30b.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Yamada Kun y Las 7 Brujas[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_125+"/",
        thumbnail="https://i.imgur.com/CwfvdAU.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Yu Gi Oh Gx[COLOR yellow] Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_126+"/",
        thumbnail="https://i.imgur.com/6G7OpqV.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )

    addDir( 
        #action="", 
        title="[COLOR aqua]Zetman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_127+"/",
        thumbnail="https://i.imgur.com/DcvpkAi.jpg",
		fanart="https://i.imgur.com/DOQO3Or.jpg",
        folder=True )	

    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
