# -*- coding: cp1252 -*-

import requests
from bs4 import BeautifulSoup
import xbmc,os,xbmcgui,xbmcaddon,xbmcplugin
import urllib
import re

i = 0
j = 0
w = 0

AddonID = 'plugin.executable.redecanais'
Addon = xbmcaddon.Addon(AddonID)
AddonName = Addon.getAddonInfo("name")

def play(url):
        name ="RedeCanais"
        iconimage = ""
	listitem = xbmcgui.ListItem(path=url, thumbnailImage=iconimage)
	listitem.setInfo(type="Video", infoLabels={ "Title": name })
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
    
def play_video(url):
    xbmc.log(url)
    rgx = "|Referer=https://redecanais.bz/%7CUser-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36 Edge/79.0.309.51"
    filekodi = xbmc.translatePath('special://home/media/abra.m3u')
    arqf = open(filekodi,'w')
    arqf.write("#EXTM3U\n")
    arqf.write("#EXTINF:-1,RedeCanais\n")
    chaman = ''+url+''+rgx+''
    arqf.write(''+url+''+rgx+'')
    arqf.close()
    #xbmc.executebuiltin('XBMC.PlayMedia(special://home/media/abra.m3u)')
    play(chaman)
    
    
    



def pegar_mp4(url):
    pagina_de_busca2 = requests.get(url)
    soup2 = BeautifulSoup(pagina_de_busca2.text, "html.parser")
    
    for player in soup2.find_all('video', attrs={'id': 'RedeCanaisPlayer'}):
        data3 = str(player)
        if player.source:
            player2 = player.source.attrs['src']
            play_video(player2)
            
            
            



        
def conv_link(links):
    #print(links)
    base = "https://redecanais.pictures/"
    conn = requests.get(links)
    soup = BeautifulSoup(conn.text, "html.parser")
    
    for player in soup.find_all('iframe', attrs={'"="': ''}):
        data2 = str(player)
        link = data2.replace('<iframe =""="" allowfullscreen="" frameborder="0" height="400" name="Player" scrolling="no" src="','').replace('" width="640"> </iframe>','').replace("&amp;","&")
        
        urlp = ""+base+""+link+""
        
        if link.find("server"):
            urlp2 = urlp#.replace('.php','player.php')
            #print(urlp2)
            pegar_mp4(urlp2)
   
        break

for param in sys.argv:
        link = str(param)
        links = re.sub("plugin://plugin.executable.redecanais/",r"",link)
        conv_link(links)
        

