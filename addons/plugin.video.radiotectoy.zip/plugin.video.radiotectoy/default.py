# -*- coding: utf-8 -*- 

import sys
import xbmc
url = "https://8874.brasilstream.com.br/stream"
xbmc.Player().play(url)