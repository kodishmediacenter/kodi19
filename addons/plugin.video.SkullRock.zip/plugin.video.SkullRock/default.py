
# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.SkullRock'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

icon2 = "https://cld.pt/dl/download/3b99dc14-e463-4c2b-97c1-c5d40c1afdf0/Concert.png?download=true"
icon3 = "https://cld.pt/dl/download/9e2e481a-571e-4f7b-bce5-5674fb10b543/clips.png?download=true"
icon4 = "https://cld.pt/dl/download/1cdab752-ecc1-4b00-8faa-da086df665e9/ACDC.png?download=true"
icon5 = "https://cld.pt/dl/download/5c68f47a-d2b7-43fa-a3a1-8b4d205c93a0/AERO.png?download=true"
icon6 = "https://i.ytimg.com/vi/NoZ7EsVoNF0/sddefault.jpg"
icon7 = "https://i.ytimg.com/vi/DtlvUQvdyoE/hqdefault.jpg"
icon8 = "http://brenocds.net/wp-content/uploads/2016/02/Sertanejo-Universit%C3%A1rio-2016-1.jpg"
icon9 = "https://i.ytimg.com/vi/9I7rTVwVlWk/maxresdefault.jpg"
icon10 = "https://www.lojadosomautomotivo.com.br/media/wysiwyg/botoesmusicas/sertanejo_modao.jpg"
icon11 = "http://jornalouvidor.com.br/public/img/uploaded_m/site_ouvidor_0-2015-09-25-05-51-00_MzYxMzY1NDg0.jpg"
icon12 = "https://i.ytimg.com/vi/by4wfrPEgQs/hqdefault.jpg"
icon13 = "http://blog.lojadosomautomotivo.com.br/wp-content/uploads/capajulhocetto.jpg"
icon14 = "https://i.ytimg.com/vi/gPxGK5wdrFA/hqdefault.jpg"

YOUTUBE_CHANNEL_ID = "playlist/PLNtZ1Pn1y2b5DSYQVARmkwwPkmtEZCvHy"
YOUTUBE_CHANNEL_ID2 = "playlist/PLNtZ1Pn1y2b5MZt68GqV1eb-ybY4kjZ04"
YOUTUBE_CHANNEL_ID3 = "playlist/PLNtZ1Pn1y2b7W1lbOINE3TKqXFqp5-e0-"
YOUTUBE_CHANNEL_ID4 = "playlist/PLNtZ1Pn1y2b6xT99-dTjTDlxtdZNIw3In"
YOUTUBE_CHANNEL_ID5 = "channel/UCMI_PyqvkI4kQhH-bau37wg"
YOUTUBE_CHANNEL_ID6 = "playlist/PLAEq5ujOZ71oMpipE1fAf5EeDYNnvjcve"
YOUTUBE_CHANNEL_ID7 = "playlist/PL6_E1Va4YJ_uvfKxixk4R7VkQDsgQQ4iK"
YOUTUBE_CHANNEL_ID8 = "playlist/PL6_E1Va4YJ_tiD7o_CkjnhTA8JVBB3szX"
YOUTUBE_CHANNEL_ID9 = "playlist/PL2xxb1HYnEobNlb3vwjhmbGBffX1VpyBz"
YOUTUBE_CHANNEL_ID10 = "playlist/PL5D23892C80A2293B"
YOUTUBE_CHANNEL_ID11 = "playlist/PL721FF7BCD77A7362"
YOUTUBE_CHANNEL_ID12 = "playlist/PLZ5j7_H_S7A0WlXmnQ8i7jJgjWKGHIj4G"
YOUTUBE_CHANNEL_ID13 = "playlist/PLDdAfEWHrSau_RwfIY6hnp_FAYIX694Eu"



def addDir(title,url,thumbnail):
    ICON = thumbnail
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title})
    liz.setArt({'thumb':ICON,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
if __name__ == '__main__':
    addDir(
                    title = "CONCERT",
                    url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID+"/",
                    thumbnail = icon2)
                    
    addDir(
                    title = "SELECTING CLIPS",
                    url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",
                    thumbnail = icon3)

    addDir(
                    title = "AC/DC",
                    url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",
                    thumbnail = icon4)		

    addDir(
                    title = "AEROSMITH",
                    url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",
                    thumbnail = icon5)		
    addDir(
                    title = "VEVO TOP 100 SERTANEJO - 2016",
                    url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID6+"/",
                    thumbnail = icon7)	
                    
    addDir(
                    title = "SERTANEJO UNIVERSITARIO",
                    url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID7+"/",
                    thumbnail = icon8)	
    addDir(
                    title = "LANCAMENTO SERTANEJO UNIVERSITARIO",
                    url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID8+"/",
                    thumbnail = icon9)	
    addDir(
                    title = "MODAO SERTANEJO",
                    url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID13+"/",
                    thumbnail = icon14)	
                    
    addDir(
                    title = "SERTANEJO ANTIGO",
                    url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID12+"/",
                    thumbnail = icon13)	
                    
    addDir(
                    title = "FLASH BACK SERTANEJO",
                    url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID5+"/",
                    thumbnail = icon6)
    addDir(
                    title = "SERTANEJO APAIXONADO(ANTIGAS)",
                    url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID9+"/",
                    thumbnail = icon10)
    addDir(
                    title = "SERTANEJO RAIZ",
                    url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID10+"/",
                    thumbnail = icon11)		
    addDir(
                    title = "MODA DE VIOLA",
                    url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID11+"/",
                    thumbnail = icon12)	
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
