# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Thanks To: Google Search For This Template
# modified by: Catoal
# A diferencia de otros impresentables yo permito que este addon
# sea utilizado como mas se desee.
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon,xbmcvfs

import base64

#from addon.common.addon import Addon

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

addonPath           = xbmcaddon.Addon().getAddonInfo("path")
mi_data = xbmcvfs.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.carnaval2023/'))
mi_addon = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.video.carnaval2023'))

setting = xbmcaddon.Addon().getSetting
if setting('youtube_usar') == "0":  ##Reproducir con Youtube
    usa_duffyou = False
else:  ##Reproducir con Duff You
    usa_duffyou = True

playlists = xbmcvfs.translatePath(os.path.join('special://home/userdata/playlists', ''))

addonID = 'plugin.video.carnaval2023'
#addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_playlist_ID_1 = "PLx1M1YkDHJCH4KhT22VisEqXb9e0t9uP5"
YOUTUBE_playlist_ID_2 = "PLvy5-Az03---2myx7ItUw1BLvXBpyT27f"
YOUTUBE_playlist_ID_3 = "PLRXZb1zxauGoRZ_0nVeAkAboUggt2DnI-"
YOUTUBE_playlist_ID_4 = "PLYnL7MCwufm76qiYR_annyVSpUlF-l5RN"


if usa_duffyou:  ##Usamos plugin Duff You
    YOUTUBE_search = "plugin://plugin.video.duffyou/?eydhY3Rpb24nOiAnb2lPTzAwT28nLCAnZmFuYXJ0JzogJ0M6XFxVc2Vyc1xcZGFyaW9cXEFwcERhdGFcXFJvYW1pbmdcXEtvZGlcXGFkZG9uc1xccGx1Z2luLnZpZGVvLmR1ZmZ5b3VcXGZhbmFydC5qcGcnLCAnaWNvbic6ICdDOlxcVXNlcnNcXGRhcmlvXFxBcHBEYXRhXFxSb2FtaW5nXFxLb2RpXFxhZGRvbnNcXHBsdWdpbi52aWRlby5kdWZmeW91XFxyZXNvdXJjZXNcXG1lZGlhXFxuZXdfc2VhcmNoLnBuZycsICdsYWJlbCc6IHUnW0JdTnVldmEgQlx4ZmFzcXVlZGFbL0JdJywgJ3BhZ2UnOiAxLCAncGxvdCc6IHUnW0JdQnVzY2FyWy9CXVtDUl1bQ1JdQnVzY2EgdW4gdmlkZW8sIHVuIGRpcmVjdG8sIHVuYSBwbGF5bGlzdCBvIHVuIGNhbmFsLicsICdxdWVyeSc6IFRydWUsICd0aXBvJzogJ3ZpZGVvJ30%3d"
else:
    #YOUTUBE_search = "plugin://plugin.video.youtube/kodion/search/list/" 
    YOUTUBE_search = "plugin://plugin.video.youtube/kodion/search/input/"



def run():
	plugintools.log('[%s %s] Running %s... ' % (addonName, addonVersion, addonName))

	# Obteniendo parámetros...
	params = plugintools.get_params()
    
	
	if params.get("action") is None:
		main_list(params)
	else:
		action = params.get("action")
		exec(action+"(params)")
        

	plugintools.close_item_list()   



# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec(action+"(params)")
    
    plugintools.close_item_list()



# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))
    
    
    plugintools.add_item(
        #action="",
        title="Samba Enredo São Paulo 2023",
        url=playlist_duffyou(YOUTUBE_playlist_ID_1),
        thumbnail="https://bit.ly/3I8GdJT",
        folder=True )

    plugintools.add_item(
        #action="",
        title="Samba Enredo Santos 2023",
        url=playlist_duffyou(YOUTUBE_playlist_ID_4),
        thumbnail="https://bit.ly/3I8GdJT",
        folder=True )

    plugintools.add_item(
        #action="",
        title="Samba Enredo Rio de Janeiro 2023",
        url=playlist_duffyou(YOUTUBE_playlist_ID_2),
        thumbnail="https://bit.ly/3I8GdJT",
        folder=True )        

    plugintools.add_item(
        #action="",
        title="Samba Enredo Rio de Janeiro 2023 Serie Ouro",
        url=playlist_duffyou(YOUTUBE_playlist_ID_3),
        thumbnail="https://bit.ly/3I8GdJT",
        folder=True )

def playlist_duffyou(id_playlist): 

    duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNUJywgJ2xhYmVsJzogJycsICdwYWdlJzogMSwgJ3Bsb3QnOiAiIiwgJ3F1ZXJ5JzogdSIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

    if usa_duffyou:  ##Usamos plugin Duff You
        reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_playlist)
        miLista = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
    else:  ##Usamos Youtube
        miLista = "plugin://plugin.video.youtube/playlist/"+id_playlist+"/"
    
    return(miLista)

    


		
run()
