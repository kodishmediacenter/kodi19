# -*- coding: utf-8 -*- 
import xbmcvfs,xbmcgui

a = "special://home"
home = xbmcvfs.translatePath(a)

dialog = xbmcgui.Dialog()
dialog.ok('Kodish Who a Pasta Home é: ', home)
dialog.close()