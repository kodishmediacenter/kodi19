# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.video.blueandjazz'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UC9zktRjA2aI7cEZOfkDqmLg"
YOUTUBE_CHANNEL_ID2=  "channel/UCx5N5GbIQizmFLoZPCaSu0g"
YOUTUBE_CHANNEL_ID2=  "channel/UCNzyrlHTWPhyWg5aghlXPsg"

icon1 = "https://yt3.ggpht.com/ytc/AAUvwnjem3Zl6qrUbXPijuY_juxjPARCLEdNfj8v4Yv3=s256-c-k-c0x00ffffff-no-rj"
icon2 = "https://yt3.ggpht.com/ytc/AAUvwniTErMOykX8wXRO0MHZPcGk_ar4sY0rtu8QC9As=s256-c-k-c0x00ffffff-no-rj"
icon3 = "https://yt3.ggpht.com/ytc/AAUvwniEOC5a6hNnr3CQy6qo8aV1-ox9_F1OQFbREfDj=s256-c-k-c0x00ffffff-no-rj"

def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
   addDir(title = "Blues & Jazz ",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon1,)
   addDir(title = "BJazz & Blues Music",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon2,)
   addDir(title = "Blues Music ",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail = icon3,)
   
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
