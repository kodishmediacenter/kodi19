# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://akamai2-br.cdn.booyah.live/hls/1000022/34850987_720.m3u8"


xbmc.Player().play(url)