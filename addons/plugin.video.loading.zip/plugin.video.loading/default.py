# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://cdn4.showcase.com.br/live/main_480p/index.m3u8"

xbmc.Player().play(url)