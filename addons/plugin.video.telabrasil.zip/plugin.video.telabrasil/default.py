import sys
import xbmcplugin
import xbmcgui
import urllib.parse
import subprocess
import os
import xbmcvfs
import webbrowser
import platform
import shutil

addon_handle = int(sys.argv[1])
base_url = sys.argv[0]
args = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

def caminho_icone(nome_arquivo):
    return os.path.join(
        xbmcvfs.translatePath(
            "special://home/addons/plugin.video.telabrasil/resources/media/"
        ),
        nome_arquivo
    )

def abrir_como_app(url):
    sistema = platform.system()

    try:
        if sistema == "Windows":
            webbrowser.open(url)
            return

        elif sistema == "Linux":
            if shutil.which("flatpak"):
                try:
                    subprocess.Popen([
                        "flatpak",
                        "run",
                        "com.google.Chrome",
                        f"--app={url}"
                    ])
                    return
                except:
                    pass

            webbrowser.open(url)

        else:
            webbrowser.open(url)

    except Exception as e:
        xbmcgui.Dialog().notification(
            "Erro",
            str(e),
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )

def adicionar_item(nome, action):
    url = f"{base_url}?action={action}"
    item = xbmcgui.ListItem(label=nome)
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=url,
        listitem=item,
        isFolder=True
    )


def menu_principal():
    adicionar_item(" Home", "home")
    adicionar_item(" Login Gov.br", "login")
    adicionar_item(" Categorias", "categorias")
    adicionar_item(" Gêneros", "generos")
    xbmcplugin.endOfDirectory(addon_handle)

def categorias():
    adicionar_item("MinC", "minc")
    adicionar_item("Diversidade Cultural", "diversidade")
    adicionar_item("Infância", "infancia")
    adicionar_item("Juventude", "juventude")
    adicionar_item("Artes", "artes")
    adicionar_item("Brasilidade", "brasilidade")
    adicionar_item("História e Estética", "historia")
    xbmcplugin.endOfDirectory(addon_handle)

def generos():
    adicionar_item("Ficção", "ficcao")
    adicionar_item("Documentário", "documentario")
    adicionar_item("Animação", "animacao")
    adicionar_item("Experimental", "experimental")
    xbmcplugin.endOfDirectory(addon_handle)

def abrir_url(action):
    urls = {
        "home": "https://telabrasil.cultura.gov.br/",
        "login": "https://sso.acesso.gov.br/login?client_id=p-telabrasil.cultura.gov.br",
        "minc": "https://telabrasil.cultura.gov.br/categoria/6",
        "diversidade": "https://telabrasil.cultura.gov.br/categoria/1",
        "infancia": "https://telabrasil.cultura.gov.br/categoria/7",
        "juventude": "https://telabrasil.cultura.gov.br/categoria/8",
        "artes": "https://telabrasil.cultura.gov.br/categoria/12",
        "brasilidade": "https://telabrasil.cultura.gov.br/categoria/82",
        "historia": "https://telabrasil.cultura.gov.br/categoria/223",
        "ficcao": "https://telabrasil.cultura.gov.br/genero/32",
        "documentario": "https://telabrasil.cultura.gov.br/genero/5",
        "animacao": "https://telabrasil.cultura.gov.br/genero/6",
        "experimental": "https://telabrasil.cultura.gov.br/genero/45"
    }

    if action in urls:
        abrir_como_app(urls[action])

if not args:
    menu_principal()
else:
    action = args.get("action")

    if action == "categorias":
        categorias()
    elif action == "generos":
        generos()
    else:
        abrir_url(action)