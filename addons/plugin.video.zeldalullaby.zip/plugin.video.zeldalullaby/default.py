# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
import requests,json
# Plugin Info

ADDON_ID      = 'plugin.video.zeldalullaby'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "playlist/PLV-IlRp1qaAQw-O9Bdr46jx1GgyFn-Eqo"
icon1 = "https://lh3.googleusercontent.com/r26SBJG46vd1BtwmprkAtR_tw99ACVA3jWkx3melaWe7hDqZrjrTePr59DFa5LwbOYJb7hyurts-LXOx=w544-h544-l90-rj"
name = "Zelda Lullabies"

YOUTUBE_CHANNEL_ID1=  "playlist/PLV-IlRp1qaAQw-O9Bdr46jx1GgyFn-Eqo"
icon1 = "https://lh3.googleusercontent.com/r26SBJG46vd1BtwmprkAtR_tw99ACVA3jWkx3melaWe7hDqZrjrTePr59DFa5LwbOYJb7hyurts-LXOx=w544-h544-l90-rj"
name = "Zelda Lullabies"

YOUTUBE_CHANNEL_ID2=  "playlist/PLV-IlRp1qaAQVzDJnJSeDIb64eSmhWbpo"
icon2 = "https://yt3.googleusercontent.com/sJh6OMFpl6-J6vq8AQBavOIDSGDbzU6SFy6smkXHONXL1s-_mD-vbhiVfnzNQ2g5ULLzLBacJuM=s1200"
name2 = "Zelda Piano Tales"

YOUTUBE_CHANNEL_ID3=  "playlist/PLV-IlRp1qaAR4yDi9RidZbrwN0Vh2qw0V"
icon3 = "https://yt3.googleusercontent.com/g64yVfhE_xfweaarx7dIg2xMwGvcCG0YLAe3Aw9bCPvpPRUH-in3aheFs8w5vgfIVkBREIjajA=s1200"
name3= "The Legend of Zelda Piano & Violin Collection"

def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
   addDir(title = name,url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon1,)
   addDir(title = name2,url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon2,)
   addDir(title = name3,url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail = icon3,)
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
