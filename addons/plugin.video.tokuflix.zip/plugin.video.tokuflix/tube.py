# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.tokuflix'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UCMOwiW6WVD_AHwZ26ydgkXg"
YOUTUBE_CHANNEL_ID2=  "channel/UCCsGCiyR-vqUqm2Ka8UeY7g"
YOUTUBE_CHANNEL_ID3=  "channel/UCKhUpux1TKBzwgftfnsJSSg"
YOUTUBE_CHANNEL_ID4=  "channel/UCJxYIPSzLKCFI8dyc-4nX4A"

icon2 = "https://yt3.ggpht.com/a/AATXAJxHXVYsNqJRBDgR9V3s8TmjZIPBMtBTXo0bPA=s256-c-k-c0xffffffff-no-rj-mo"
icon3 = "https://yt3.ggpht.com/a/AATXAJynn_5pwH6XnWGJCLfYwFCQRC4IOrxzhTzjSA=s256-c-k-c0xffffffff-no-rj-mo"
icon4 = "https://yt3.ggpht.com/a/AATXAJwrx9tKCKjq2Uhj1Se_PyiGKW2m_IpsiKcOV2V4=s256-c-k-c0xffffffff-no-rj-mo"
icon5 = "https://yt3.ggpht.com/a/AATXAJzBfsd1afGNni6rLrQSIYf4I6oX-cApcGgkdA=s256-c-k-c0xffffffff-no-rj-mo"


def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
def youtube_panel():
   addDir(title = "TokuDoc - Almanaque do Tokusatsu",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon2,)
   addDir(title = "Resistencia Tokusatsu",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon3,)
   addDir(title = "Herois das Antigas",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail = icon4,)
   addDir(title = "GERAÇÃO JASPION Brasil",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",thumbnail = icon5,)
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)

	


