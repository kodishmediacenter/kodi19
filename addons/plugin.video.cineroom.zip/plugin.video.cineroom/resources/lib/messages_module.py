import urllib.request
import xbmcgui
import xbmcplugin

def listar_mensagens(addon_id, handle):
    """Exibe a opção de visualizar informações."""
    url_mensagens = "https://raw.githubusercontent.com/cineroom1/infos/refs/heads/main/info.txt"  # URL do arquivo de informações
    list_item = xbmcgui.ListItem(label="[COLOR gold]Informações[/COLOR]")  # Altera o rótulo para "Info"
    url = f"plugin://{addon_id}/?action=mostrar_mensagens&url={url_mensagens}"
    xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

def mostrar_mensagens(url_mensagens):
    """Carrega o conteúdo da URL e exibe no TextViewer."""
    try:
        # Baixa o conteúdo do arquivo de mensagens
        response = urllib.request.urlopen(url_mensagens)
        mensagens = response.read().decode('utf-8')

        # Exibe as mensagens no TextViewer
        xbmcgui.Dialog().textviewer("Mensagens", mensagens)
    except Exception as e:
        xbmcgui.Dialog().notification("Erro", f"Não foi possível carregar as mensagens: {str(e)}")
