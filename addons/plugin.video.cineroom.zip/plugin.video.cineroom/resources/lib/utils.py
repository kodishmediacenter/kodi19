import json
import urllib.request
import xbmcgui
import sys  # Adiciona a importação do sys

def fetch_data_from_url(url):
    """
    Faz a requisição HTTP para buscar o arquivo JSON hospedado em uma URL.
    """
    try:
        response = urllib.request.urlopen(url)
        data = response.read().decode('utf-8')
        return json.loads(data)
    except Exception as e:
        xbmcgui.Dialog().notification('Erro', f'Não foi possível buscar os dados: {e}', xbmcgui.NOTIFICATION_ERROR)
        return []

def get_url(action, **kwargs):
    """
    Gera a URL para ações do plugin.
    """
    base_url = f'{sys.argv[0]}?action={action}'  # sys agora está disponível
    for key, value in kwargs.items():
        base_url += f'&{key}={value}'
    return base_url
