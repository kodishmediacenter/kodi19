# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.video.hunterfm'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UCQNN7INAt1yS_v0P0tSlbrQ"
icon1 = "https://yt3.ggpht.com/ytc/AKedOLTaPNR9KLDI9CHe7z_T8GVSnRhxYROahjPH0ShkdQ=s256-c-k-c0x00ffffff-no-rj"

def addDir2(title, url, thumbnail):
    import xbmc
    xbmc.Player().play(url)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)


def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':

       dialog = xbmcgui.Dialog()
       linka = dialog.select('Radio Hunter', ['[COLOR white][B]Hunter Auta Qualidade[/B][/COLOR]','[COLOR white][B]Hunter Qualidade Normal[/B][/COLOR]','[COLOR white][B]Hunter Qualidade Low[/B][/COLOR]'])
       
       if linka == 0: 
           dialog = xbmcgui.Dialog()
           link = dialog.select('Radio Hunter High Quality', ['[COLOR white][B]Hunter Pop[/B][/COLOR]','[COLOR white][B]Hunter Sertanejo[/B][/COLOR]','[COLOR white][B]Hunter Gospel[/B][/COLOR]','[COLOR white][B]Hunter Pisadinha[/B][/COLOR]','[COLOR white][B]Hunter Rock[/B][/COLOR]','[COLOR white][B]Hunter Tropical[/B][/COLOR]','[COLOR white][B]Hunter Lofi[/B][/COLOR]','[COLOR white][B]Hunter Pop2K[/B][/COLOR]','[COLOR white][B]Hunter Anos 80[/B][/COLOR]','[COLOR white][B]Hunter Smash[/B][/COLOR]'])
           
           if link == 0:
                url = "https://live.hunter.fm/pop_high"
                xbmc.Player().play(url)

           if link == 1:
                url = "https://live.hunter.fm/sertanejo_high"
                xbmc.Player().play(url) 
                
           if link == 2:
                url = "https://live.hunter.fm/gospel_high"
                xbmc.Player().play(url)   

           if link == 3:
                url = "https://live.hunter.fm/pisadinha_high"
                xbmc.Player().play(url)

           if link == 4:
                url = "https://live.hunter.fm/rock_high"
                xbmc.Player().play(url)  
           
           if link == 5:
                url = "https://live.hunter.fm/tropical_high"
                xbmc.Player().play(url) 

       

           if link == 6:
                url = "https://live.hunter.fm/lofi_high"
                xbmc.Player().play(url)

           if link == 7:
                url = "https://live.hunter.fm/pop2k_high"
                xbmc.Player().play(url)  
           
           if link == 8:
                url = "https://live.hunter.fm/80s_high"
                xbmc.Player().play(url)  

           if link == 9:
                url = "https://live.hunter.fm/smash_high"
                xbmc.Player().play(url)        
            
            

            
       if linka == 1: 
           dialog = xbmcgui.Dialog()
           link = dialog.select('Radio Hunter Normal Quality', ['[COLOR white][B]Hunter Pop[/B][/COLOR]','[COLOR white][B]Hunter Sertanejo[/B][/COLOR]','[COLOR white][B]Hunter Gospel[/B][/COLOR]','[COLOR white][B]Hunter Pisadinha[/B][/COLOR]','[COLOR white][B]Hunter Rock[/B][/COLOR]','[COLOR white][B]Hunter Tropical[/B][/COLOR]','[COLOR white][B]Hunter Lofi[/B][/COLOR]','[COLOR white][B]Hunter Pop2K[/B][/COLOR]','[COLOR white][B]Hunter Anos 80[/B][/COLOR]','[COLOR white][B]Hunter Smash[/B][/COLOR]'])
           
           if link == 0:
                url = "https://live.hunter.fm/pop_normal"
                xbmc.Player().play(url)

           if link == 1:
                url = "https://live.hunter.fm/sertanejo_normal"
                xbmc.Player().play(url) 
                
           if link == 2:
                url = "https://live.hunter.fm/gospel_normal"
                xbmc.Player().play(url)   

           if link == 3:
                url = "https://live.hunter.fm/pisadinha_normal"
                xbmc.Player().play(url)

           if link == 4:
                url = "https://live.hunter.fm/rock_normal"
                xbmc.Player().play(url)  
           
           if link == 5:
                url = "https://live.hunter.fm/tropical_normal"
                xbmc.Player().play(url) 

       

           if link == 6:
                url = "https://live.hunter.fm/lofi_normal"
                xbmc.Player().play(url)

           if link == 7:
                url = "https://live.hunter.fm/pop2k_normal"
                xbmc.Player().play(url)  
           
           if link == 8:
                url = "https://live.hunter.fm/80s_normal"
                xbmc.Player().play(url)  

           if link == 9:
                url = "https://live.hunter.fm/smash_normal"
                xbmc.Player().play(url)        


       if linka == 2: 
           dialog = xbmcgui.Dialog()
           link = dialog.select('Radio Hunter Low Quality', ['[COLOR white][B]Hunter Pop[/B][/COLOR]','[COLOR white][B]Hunter Sertanejo[/B][/COLOR]','[COLOR white][B]Hunter Gospel[/B][/COLOR]','[COLOR white][B]Hunter Pisadinha[/B][/COLOR]','[COLOR white][B]Hunter Rock[/B][/COLOR]','[COLOR white][B]Hunter Tropical[/B][/COLOR]','[COLOR white][B]Hunter Lofi[/B][/COLOR]','[COLOR white][B]Hunter Pop2K[/B][/COLOR]','[COLOR white][B]Hunter Anos 80[/B][/COLOR]','[COLOR white][B]Hunter Smash[/B][/COLOR]'])
           
           if link == 0:
                url = "https://live.hunter.fm/pop_low"
                xbmc.Player().play(url)

           if link == 1:
                url = "https://live.hunter.fm/sertanejo_low"
                xbmc.Player().play(url) 
                
           if link == 2:
                url = "https://live.hunter.fm/gospel_low"
                xbmc.Player().play(url)   

           if link == 3:
                url = "https://live.hunter.fm/pisadinha_low"
                xbmc.Player().play(url)

           if link == 4:
                url = "https://live.hunter.fm/rock_low"
                xbmc.Player().play(url)  
           
           if link == 5:
                url = "https://live.hunter.fm/tropical_low"
                xbmc.Player().play(url) 

       

           if link == 6:
                url = "https://live.hunter.fm/lofi_low"
                xbmc.Player().play(url)

           if link == 7:
                url = "https://live.hunter.fm/pop2k_low"
                xbmc.Player().play(url)  
           
           if link == 8:
                url = "https://live.hunter.fm/80s_low"
                xbmc.Player().play(url)  

           if link == 9:
                url = "https://live.hunter.fm/smash_low"
                xbmc.Player().play(url)        
