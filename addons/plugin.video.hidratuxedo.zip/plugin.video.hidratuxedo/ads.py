import xbmc

def main():
    # URL da imagem que você deseja exibir
    url_da_imagem = 'https://raw.githubusercontent.com/kodishmediacenter/Rework-HidraMX/main/ads/1.png'

    # Executa o comando para exibir a imagem
    xbmc.executebuiltin('ShowPicture({})'.format(url_da_imagem))

if __name__ == '__main__':
    main()
