# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
import requests,json
# Plugin Info

ADDON_ID      = 'plugin.video.hidratuxedo'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UCZiYbVptd3PVPf4f6eR6UaQ/live"
icon1 = "https://yt3.ggpht.com/e0nTVFqGa9UzKQw5mOzIKLajiBgwslJQOsn-UzOzdjzQq5wuCjDt-Kuq_hwPOCUBst-z7HJ1ugg=s800-c-k-c0x00ffffff-no-rj"
ids = YOUTUBE_CHANNEL_ID1
name = "Cine Clássico"
def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

def main():
   addDir(title = name,url = "plugin://plugin.video.youtube/"+ids+"/",thumbnail = icon1,)
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
