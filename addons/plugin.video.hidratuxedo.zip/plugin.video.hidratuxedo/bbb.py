import xbmc
import xbmcgui

def web_browser(urlcn):
        import webbrowser
        if xbmc . getCondVisibility ( 'system.platform.android' ) :
                ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+urlcn+'' ) )
        else:
                ost = webbrowser . open ( ''+urlcn+'' )







def conect():
    dialog = xbmcgui.Dialog()
    player = dialog.select('Kodish Store - Rammeta', ['Multicanais','Canais Play'])

    if player == 0:
            url = "https://multicanais.bid/assistir-bbb-24-ao-vivo-online-24-horas-gratis-em-hd/"
            web_browser(url)
    else: 
            url = "https://bbb.fm/"
            web_browser(url)


