import xbmcgui
import webbrowser

def internet(url):
    if xbmc . getCondVisibility ( 'system.platform.android' ) :
        ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+url+'' ) )
    else:
        ost = webbrowser . open ( ''+url+'' )   


dialog = xbmcgui.Dialog()
link = dialog.select('Vix Laucher', ['Filmes','Vix Explorer','Series','Manda Brasa','Novelas Latinas','Royals','Vix Hacks','Vix Glan','Urban Food','Vix Viaja','Vix Yum','Series en Español'])

if link == 0:
    url = "https://www.vix.com/tv/channels/moovies/5ede875bb2d01f1330cb0322"
    internet(url)

if link == 1:
    url = "https://www.vix.com/tv/channels/explore/5ee2c2c5907a4f12e8e879c7"
    internet(url)

if link == 2:
    url = "https://www.vix.com/tv/channels/series/5ee2c40683ffb81130350add"
    internet(url)

if link == 3:
    url = "https://www.vix.com/tv/channels/perdig%C3%A3o/5f74d5a867bfdf2f575992d2"
    internet(url)

if link == 4:
    url = "https://www.vix.com/tv/channels/novelas/5ee2c424deffa01330086f37"
    internet(url)

if link == 5:
    url = "https://www.vix.com/tv/channels/royals/5ee2c33ff7f64512648c2687"
    internet(url)

if link == 6:
    url = "https://www.vix.com/tv/channels/hacks/5ee2c305f7f64512648c2670"
    internet(url)

if link == 7:
    url = "https://www.vix.com/tv/channels/glam/5ee2c2e7deffa01330086ed5"
    internet(url)

if link == 8:
    url = "https://www.vix.com/tv/channels/urban-food/5f36b3414293590001d97911"
    internet(url)

if link == 9:
    url = "https://www.vix.com/tv/channels/viaja/5f36adf94293590001d97902"
    internet(url)

if link == 10:
    url = "https://www.vix.com/tv/channels/yum/5f1ef8e734b7bc0001b70a39"
    internet(url)

if link == 11:
    url = "https://www.vix.com/tv/channels/series-in-spanish/5f03ad33ef0588000149a0b4"
    internet(url)
