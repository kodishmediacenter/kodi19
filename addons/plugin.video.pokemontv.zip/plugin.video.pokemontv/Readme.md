# Kodi Video Plugin für Pokemon TV

Dies ist ein inoffizielles Video Plugin für Pokemon TV (https://watch.pokemon.com).
