# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.video.artflix'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UCNcUc5v0Kt5afE_jcbbZUBQ"
YOUTUBE_CHANNEL_ID2=  "channel/UCO7swxrJsImdC1k5WsXxANA"
YOUTUBE_CHANNEL_ID3=  "channel/UCUVH79pnWVC6aL1_uAB3ylQ"
YOUTUBE_CHANNEL_ID4=  "channel/UC4HHPJQWajtc-2UJXhv3qeg"
YOUTUBE_CHANNEL_ID5=  "channel/UCZBDzyJPnktpgHvqGaMAhBw"
YOUTUBE_CHANNEL_ID6=  "channel/UC6kbOKYgbb4c4iOkd9ovVyw"
YOUTUBE_CHANNEL_ID7=  "channel/UCV8hg-8X3YsVSw9h3-gLyvQ"

icon1 = "https://yt3.googleusercontent.com/f4oCq966vrppZeoyeBP091lrH0ALY97jgBmHTP1Q3EzwV_jezvkT7ZvVRY4O4432p8MT9MUCllE=s256-c-k-c0x00ffffff-no-rj"
def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

def main():
    addDir(title = "ARTFLIX - English",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon1,)
    addDir(title = "ARTFLIX - Spanish",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon1,)
    addDir(title = "ARTFLIX - German",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail = icon1,)
    addDir(title = "ARTFLIX - Brazil",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",thumbnail = icon1,)
    addDir(title = "ARTFLIX - French",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID5+"/",thumbnail = icon1,)
    addDir(title = "ARTFLIX - Italian",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID6+"/",thumbnail = icon1,)
    addDir(title = "ARTFLIX - Polish",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID7+"/",thumbnail = icon1,)
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)


main()
