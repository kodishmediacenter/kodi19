import xbmcvfs
import xbmcgui




home = xbmcvfs.translatePath("special://home/userdata/playercorefactory.xml")
addon = xbmcvfs.translatePath("special://home/addons/player/mpv.exe")
filez = open(home,"a") 

filez.write('<playercorefactory> \n')
filez.write('        <players> \n')
filez.write('                <player name="MPV" type="ExternalPlayer" audio="false" video="true"> \n')
filez.write('                        <filename>'+addon+'</filename> \n')
filez.write('                        <args> --fs</args> \n')
filez.write('                        <hidexbmc>true</hidexbmc> \n')
filez.write('                </player>    \n')
filez.write('        </players> \n')
filez.write('        <rules action="prepend"> \n')
filez.write('                 <rule video="true" player="MPV"/>\n')
filez.write('        </rules> \n')
filez.write('</playercorefactory> \n')
filez.flush()
filez.close()


# Crie um diálogo
dialog = xbmcgui.Dialog()
dialog.ok("MPV patch", "Patch Aplicado com sucesso")
                        

    




