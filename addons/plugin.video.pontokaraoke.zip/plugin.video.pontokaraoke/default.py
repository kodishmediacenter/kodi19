# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
import requests,json
# Plugin Info

ADDON_ID      = 'plugin.video.pontokaraoke'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')


icon1 = "https://yt3.googleusercontent.com/JUZuRRF2lwIx2J0U2Ig5Hk8n9_LeEDcE9A5ejGRqWj_zIbdY8BReYUSmP2Sr5Br5Re48QHwTLg=s256-c-k-c0x00ffffff-no-rj"

YOUTUBE_CHANNEL_ID1=  "channel/UCtyCCrtjjTerQbGebVzekWA"
ids = YOUTUBE_CHANNEL_ID1
name = "Ponto Karaoke 1"

YOUTUBE_CHANNEL_ID2=  "channel/UCRKCTVnBNVX9jDDNaFhPk1A"
ids2 = YOUTUBE_CHANNEL_ID2
name2 = "Ponto Karaoke 2"

YOUTUBE_CHANNEL_ID3=  "channel/UCkEUAI-G5YUSXOBcazgpnUA"
ids3 = YOUTUBE_CHANNEL_ID3
name3 = "Ponto Karaoke 3"

def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
   addDir(title = name,url = "plugin://plugin.video.youtube/"+ids+"/",thumbnail = icon1,)
   addDir(title = name2,url = "plugin://plugin.video.youtube/"+ids2+"/",thumbnail = icon1,)
   addDir(title = name3,url = "plugin://plugin.video.youtube/"+ids3+"/",thumbnail = icon1,)   
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
