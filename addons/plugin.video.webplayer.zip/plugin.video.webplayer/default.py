# -*- coding: utf-8 -*-

import sys
import xbmcvfs,xbmc
import re
import os




log1 = xbmcvfs.translatePath("special://home/addons/plugin.video.webplayer/log.txt")
log2 = xbmcvfs.translatePath("special://home/addons/plugin.video.webplayer/log2.txt")             
log3 = xbmcvfs.translatePath("special://home/addons/plugin.video.webplayer/log3.txt")             

files = open(log1,"w")
filess = open(log2,"w")
files.write("")
filess.write("")
files.close()
filess.close()

def web_browser(urlcn):
        import webbrowser
        if xbmc . getCondVisibility ( 'system.platform.android' ) :
                ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+urlcn+'' ) )
        else:
                ost = webbrowser . open ( ''+urlcn+'' )


data = sys.argv
    # plugin://plugin.video.webplayer/play?uri=
torrent = str(data)
torrentconv = re.sub('plugin://plugin.video.webplayer', r'', torrent)
torrentconv2 = re.sub("(.*)?uri=",r'',torrentconv)
filesz = open(log3,"w")
filesz.write(torrentconv2.replace("', 'resume:false']",""))
filesz.close()
 
url = torrentconv2.replace("', 'resume:false']","")
web_browser(url)