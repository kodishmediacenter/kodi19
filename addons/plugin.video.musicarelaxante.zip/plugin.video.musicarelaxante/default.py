# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.video.musicarelaxante'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UCDXpLJi-8QdilIrD8BzPZvw"
icon1 = "https://yt3.ggpht.com/ytc/AAUvwnhKuWlkB1uvXn8kHftP-ANpnkegUI_beyzaN5YP=s256-c-k-c0x00ffffff-no-rj"

YOUTUBE_CHANNEL_ID2=  "channel/UCG4n9vGUd2KOKT9623zoJeA"
icon2 = "https://yt3.ggpht.com/ytc/AAUvwnhSAp1FPfgaIINKP592eEmVTy5sA68EJkofrUf9=s256-c-k-c0x00ffffff-no-rj"

YOUTUBE_CHANNEL_ID3=  "channel/UCyTtJxA6iTkQldckbRIU-tw"
icon3 = "https://yt3.ggpht.com/ytc/AAUvwniOHf4Sg5B1a2ANWjBAR3Nb51vrfmze5RwhUOO0=s256-c-k-c0x00ffffff-no-rj-mo"


YOUTUBE_CHANNEL_ID4=  "channel/UClnySsXJ3yolpgqzMaFgntw"
icon4 = "https://yt3.ggpht.com/ytc/AAUvwnjeVLqoFQhE1hKrnwy4wlhITDzltQtX0SX-vXrPCQ=s256-c-k-c0x00ffffff-no-rj"

YOUTUBE_CHANNEL_ID5=  "channel/UCLPiNPzZkDUnnMWLEp_fqZA"
icon5 = "https://yt3.ggpht.com/ytc/AAUvwnjNm_5UFhKR8V0rpOJjUrcwt4XIIBfPICZse-C2=s256-c-k-c0x00ffffff-no-rj-mo"

YOUTUBE_CHANNEL_ID6=  "channel/UCVTkSOR1KdxNGS7rT4bzkEA"
icon6 = "https://yt3.ggpht.com/ytc/AAUvwngOudL-HCtdwLiTXKlBU_VYCINAdder3mVIqlOG=s256-c-k-c0x00ffffff-no-rj-mo"





def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
    
   addDir(title = "Beautiful Relaxing Music",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon1,)
   addDir(title = "Dream Sound",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon2,)
   addDir(title = "Dream Relaxation",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail = icon3,)
   addDir(title = "Musica para Dormir",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",thumbnail = icon4,)
   addDir(title = "Deep Music 24h",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID5+"/",thumbnail = icon5,)
   addDir(title = "Musica Relajante - Beautiful Dreams",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID6+"/",thumbnail = icon6,)
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
