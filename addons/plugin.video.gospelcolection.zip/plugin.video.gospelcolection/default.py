# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.gospelcolection'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

def addDir(title, url):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':ICON,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    


base    = 'plugin://plugin.video.youtube/'



if __name__ == '__main__':
    addDir(title = "Gospel Colection Mix 1"         , url = base + "playlist/PL_Q15fKxrBb4pxTp2zQm6zZU3-h4dlm05/")
    addDir(title = "Gospel Colection Mix 2"         , url = base + "playlist/PLjwDi_dm6srlAU54JHsDwaMWb9jmTvysq/")
    addDir(title = "As Melhores Musicas Gospel e Mais Tocadas"         , url = base + "playlist/PL2296dlVp4DPuI0B053-nQU9D30GWONW5/")
    addDir(title = "Louvores Para Acalmar A Alma em 2019"         , url = base + "playlist/PLKy-MuzQusGDK1VWdImCMEw7J6S4fQgCB/")                
    #addDir(title = "As melhores mÃºsicas gospel mais tocadas"         , url = base + "playlist/PLqb5MhlswtopztyMGjsMfceIm6Phzyi5j/")
    #addDir(title = "As Melhores MÃºsicas Gospel Mais Tocadas 2"         , url = base + "playlist/PLGu_O2_84gnVbUlsqrbSGQYHjvRSNcJo-/")
    addDir(title = "As Melhores Musicas Gospel Mais Tocadas 2019 - Anderson Freire, Aline Barros"         , url = base + "playlist/PLoZREtoAvBufg-_a7NHYBRkyKyTXfxxxb/")
    addDir(title = "top 10 musicas gospel - Melhores mÃºsicas gospel mais tocadas - musicas gospel"         , url = base + "playlist/PLHRfvZ6qvZfjhyajTKyV5VZcVnSyn9kFS/")

    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
