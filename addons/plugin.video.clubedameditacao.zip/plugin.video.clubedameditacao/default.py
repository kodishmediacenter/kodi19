# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.topmusic'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UCPpL7YTaYvSAcq9RtqWqa9w"
YOUTUBE_CHANNEL_ID2=  "channel/UCLzC4_8mS7RSQh5EcNHBIZQ"
YOUTUBE_CHANNEL_ID3=  "channel/UCNSY91ER8B9R-_YHNFzk5MA"
YOUTUBE_CHANNEL_ID4=  "channel/UCk-ekd_RU9taTUWWgmM60yA"
YOUTUBE_CHANNEL_ID5=  "channel/UCuPsPs6prC5o9s4Bbh1LdTA"
YOUTUBE_CHANNEL_ID6=  "channel/UCUSzc8BHGJPaYt0DjvscIzw"
YOUTUBE_CHANNEL_ID7=  "channel/UCV50zzvN1uu8taJTjTc7dhA"
YOUTUBE_CHANNEL_ID8=  "channel/UCieVHNOU_5OglsfQn9BaZEA"
YOUTUBE_CHANNEL_ID9=  "channel/UCo1dxcgsibWFqyn8K0jgqhw"

icon1 = "https://yt3.ggpht.com/a/AATXAJzsTw7G1ULyvnefmKcslxA7DrRWInbKGDxi6KrRwg=s256-c-k-c0xffffffff-no-rj-mo"
icon2 = "https://yt3.ggpht.com/a/AATXAJxyjfBgnx3VHt2eS4_ESrHu7cD74-4twY-paXLlJA=s256-c-k-c0xffffffff-no-rj-mo"
icon3 = "https://yt3.ggpht.com/a/AATXAJx4vJkszikbKK3KSD_ePoJq3uC6SvuVWewLjEVONg=s256-c-k-c0xffffffff-no-rj-mo"
icon4 = "https://yt3.ggpht.com/a/AATXAJzCZhyVPVvoxqxJWD4V3yb7_P1gZN9WnMNw0UD_OQ=s256-c-k-c0xffffffff-no-rj-mo"
icon5 = "https://yt3.ggpht.com/a/AATXAJySI7KaykBnGl81FxG9rOmmPublgnGSbKx5moaymQ=s256-c-k-c0xffffffff-no-rj-mo"
icon6 = "https://yt3.ggpht.com/a/AATXAJwqcKna1Lx2lap3W5qONQzNX0J4lPevbbctb3dl3A=s256-c-k-c0xffffffff-no-rj-mo"
icon7 = "https://yt3.ggpht.com/a/AATXAJyDk5J9XklpVRajr6qMs_X_ZoUkyg7UMFPd9Tm4kw=s256-c-k-c0xffffffff-no-rj-mo"
icon8 = "https://yt3.ggpht.com/a/AATXAJwcpVej4iY-crSPZ8TQ6FQU_ask9bB4oUkcMKOIdg=s256-c-k-c0xffffffff-no-rj-mo"
icon9 = "https://yt3.ggpht.com/a/AATXAJy_qTe910cEVgwI8DXdb2Fy_3Iw3InYZPDaGpYPHw=s256-c-k-c0xffffffff-no-rj-mo"

def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
if __name__ == '__main__':

   addDir(title = "Clube de Meditação para Pensamentos Poderosos",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon1,)
   addDir(title = "Awakening Planet       ",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon2,)
   addDir(title = "Elevated Consciousness",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail = icon3,)
   addDir(title = "The Conscious Wave",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",thumbnail = icon4,)
   addDir(title = "Daily Ascension - Accept Your Power",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID5+"/",thumbnail = icon5,)
   addDir(title = "Woke Nation     ",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID6+"/",thumbnail = icon6,)
   addDir(title = "MoonLight Meditations     ",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID7+"/",thumbnail = icon7,)
   addDir(title = "NAMASTÈ TRIBE ॐ",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID8+"/",thumbnail = icon8,)
   addDir(title = "Miracle Tones Meditation",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID9+"/",thumbnail = icon9,)


   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)

	


