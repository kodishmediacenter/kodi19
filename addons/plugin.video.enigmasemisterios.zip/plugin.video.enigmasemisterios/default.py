# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
import requests,json
# Plugin Info

ADDON_ID      = 'plugin.video.enigmasemisterios'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UCl5Bjrnux2RGio1TPtGvx7g"
icon1 = "https://yt3.ggpht.com/ytc/AKedOLRyfVCsvr_sfaDqEMolDTX5gEOV0GkM0yWuu25C=s256-c-k-c0x00ffffff-no-rj"
thumbnail = icon1

def addDir(title, url):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
    addDir(title = "Enigmas e Misterios",url = "plugin://plugin.video.youtube/channel/UCl5Bjrnux2RGio1TPtGvx7g/",)
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)