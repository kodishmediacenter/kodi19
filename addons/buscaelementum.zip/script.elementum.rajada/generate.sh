cd ..
zip -r -u -9 -T script.elementum.rajada.zip script.elementum.rajada/ \
-x "script.elementum.rajada/.git/*" \
-x "*.pyc" \
-x "script.elementum.rajada/scripts/check_provider/*"
