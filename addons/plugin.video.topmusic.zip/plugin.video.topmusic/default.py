# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.topmusic'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UCE1rx36JdB2AY1XqQGYwVCA"
YOUTUBE_CHANNEL_ID2=  "channel/UCJGdlygRr4xaR5qGvO57Cww"
YOUTUBE_CHANNEL_ID3=  "channel/UCXoOYMqB-rB5qXhh2yIhD0w"
YOUTUBE_CHANNEL_ID4=  "channel/UCoVYaNx-A2mWsQ366LCHuJQ"
YOUTUBE_CHANNEL_ID5=  "channel/UChGHtPWiqLcBws08YhtPH7A"
YOUTUBE_CHANNEL_ID6=  "channel/UClkRzsdvg7_RKVhwDwiDZOA"

icon1 = "https://yt3.ggpht.com/a/AATXAJxK1sGtm1po_E-jnftJneILjRz93Mm6QCQ0Aukd=s256-c-k-c0xffffffff-no-rj-mo"
icon2 = "https://yt3.ggpht.com/a/AATXAJwB5jYkRxq21vSTUhVB5n_ueQ-8CoL4km7RH_KX=s256-c-k-c0xffffffff-no-rj-mo"
icon3 = "https://yt3.ggpht.com/a/AATXAJzso42Aaw97uB710EKkL5R345ck_ETCgAETAguR=s256-c-k-c0xffffffff-no-rj-mo"
icon4 = "https://yt3.ggpht.com/a/AATXAJzhI1ccXS1B_ESbUa6NofqD-gfocHdYID-_j38-=s256-c-k-c0xffffffff-no-rj-mo"
icon5 = "https://yt3.ggpht.com/a/AATXAJzfLvwgCkVxq1Nf-7hpY30sMKBeFCFZ-idOtaGB=s256-c-k-c0xffffffff-no-rj-mo"
icon6 = "https://yt3.ggpht.com/a/AATXAJw3Nwu5fPATOVRQAmCYDuSRQ7pFdYWltiyfmVSbHw=s256-c-k-c0xffffffff-no-rj-mo"


def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
if __name__ == '__main__':

   addDir(title = "Brazil Music Box",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon1,)
   addDir(title = "Master Hits       ",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon2,)
   addDir(title = "Greatest Soft Rock",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail = icon3,)
   addDir(title = "Latin Songs       ",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",thumbnail = icon4,)
   addDir(title = "Musica Gospel",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID5+"/",thumbnail = icon5,)
   addDir(title = "JFlaMusic      ",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID6+"/",thumbnail = icon6,)
   
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)

	


