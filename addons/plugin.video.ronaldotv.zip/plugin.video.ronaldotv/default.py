# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
import requests,json
# Plugin Info

ADDON_ID      = 'plugin.video.ronaldotv'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UC5M5wBjrjPdnIUX0YDh2NYQ"
YOUTUBE_CHANNEL_ID2=  "channel/UC5M5wBjrjPdnIUX0YDh2NYQ/playlists"
YOUTUBE_CHANNEL_ID3=  "channel/UC5M5wBjrjPdnIUX0YDh2NYQ/live"

icon1 = "https://yt3.googleusercontent.com/kIRjAGieAr-CsAU9GBF1nxh_Co8z-cGTbF82oKcDS_JqlfxSfRMOVXJf_MdpHF8Q_u0BiXF0=s256-c-k-c0x00ffffff-no-rj"

ids = YOUTUBE_CHANNEL_ID1
name = "Ronaldo TV - Todos os Videos"

ids2 = YOUTUBE_CHANNEL_ID2
name2 = "Ronaldo TV Playlist"

ids3 = YOUTUBE_CHANNEL_ID3
name3 = "Ronaldo TV Ao Vivo"

def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
   addDir(title = name,url = "plugin://plugin.video.youtube/"+ids+"/",thumbnail = icon1,)
   addDir(title = name2,url = "plugin://plugin.video.youtube/"+ids2+"/",thumbnail = icon1,)
   addDir(title = name3,url = "plugin://plugin.video.youtube/"+ids3+"/",thumbnail = icon1,)
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
