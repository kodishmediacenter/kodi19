# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.video.cimorelli'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID= "playlist/PLxvNPv0hzSDD7Ir_jDjjiQicf6JOWqi4K"
YOUTUBE_CHANNEL_ID2="playlist/PLxvNPv0hzSDCcMCAQNF7XZNlfXWgYt4II"
YOUTUBE_CHANNEL_ID3="playlist/PL7B71B644B0166239"
YOUTUBE_CHANNEL_ID4="playlist/PLF21BB70C750A7A7C"
YOUTUBE_CHANNEL_ID5="playlist/PLxvNPv0hzSDCXJxjA0El1qvWKmJmoprNv"
YOUTUBE_CHANNEL_ID6="playlist/PL75703FBFD564AE41"
YOUTUBE_CHANNEL_ID7="playlist/PLxvNPv0hzSDACUI5lBghLzIUmL85ztcWd"
YOUTUBE_CHANNEL_ID8="playlist/PLxvNPv0hzSDDqQjfRrevgiZoSmNrOsVCP"
YOUTUBE_CHANNEL_ID9="playlist/PLxvNPv0hzSDDYR1cqDSqx-tAL3uawuMOY"

YOUTUBE_CHANNEL_ID1=  "playlist/PLxvNPv0hzSDD7Ir_jDjjiQicf6JOWqi4K"
icon1 = "https://yt3.ggpht.com/ytc/AAUvwnjROpqT-ZU3vy3dbBS3h98oME92aQ52Cdk_kRYH_A=s256-c-k-c0x00ffffff-no-rj"
icon = icon1
def addDir(title, url, thumbnail,folder):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)



if __name__ == '__main__':
  

   addDir(
		title = "Cimorelli Original Songs",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID+"/",
		thumbnail = icon,
		folder = True )
		
	addDir(
		title = "Cimorelli Style",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",
		thumbnail = icon,
		folder = True )
		
	addDir(
		title = "Other Stuff",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",
		thumbnail = icon,
		folder = True )
		
	addDir(
		title = "Cimorelli Music Videos Covers",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",
		thumbnail = icon,
		folder = True )
		
	addDir(
		title = "Summer With Cimorelli - Our Comedy Series",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID5+"/",
		thumbnail = icon,
		folder = True )
		
	addDir(
		title = "Christmas Songs",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID6+"/",
		thumbnail = icon,
		folder = True )
		
	addDir(
		title = "Our East Coast Tour",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID7+"/",
		thumbnail = icon,
		folder = True )
		
	addDir(
		title = "Cimorelli Takes Europe",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID8+"/",
		thumbnail = icon,
		folder = True )
		
	addDir(
		title = "YT Holiday Extravagannza",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID9+"/",
		thumbnail = icon,
		folder = True )

   
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
