import sys
import xbmcaddon, xbmcgui, xbmcplugin
import fire
# Plugin Info

ADDON_ID      = 'plugin.video.twtutoriais'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')



def addDir(title, url):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':ICON,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

YOUTUBE_CHANNEL_ID1=  "channel/UCgVQqobkMRRMrHQcbT1i5Fg"

if __name__ == '__main__':
    fire.byebyeBoaNoite()
    addDir(title = "[B][COLOR lime]TONY [/COLOR][COLOR darkblue]WARLLEY[/COLOR][COLOR yellow] TUTORIAIS[/COLOR][/B]",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",)
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)









