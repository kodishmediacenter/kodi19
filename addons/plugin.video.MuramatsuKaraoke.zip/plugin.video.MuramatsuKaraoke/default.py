# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.music.MuramatsuKaraoke'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')
icon  = ICON

YOUTUBE_CHANNEL_ID1=  "PLgFrDSKYT2CMlgFuuuGT5f-gk_0JDDj0R"
YOUTUBE_CHANNEL_ID2=  "PLgFrDSKYT2CMJd9rJhUmUVKvMjxUK2lCk"
YOUTUBE_CHANNEL_ID3=  "PLgFrDSKYT2CNx-vXZyUf47sraP0t5XdmI"
YOUTUBE_CHANNEL_ID4=  "PLgFrDSKYT2CP7Y9xd8pcsU_edYFwiQC01"
YOUTUBE_CHANNEL_ID5=  "PLgFrDSKYT2COR8WNnRrYxNkKqx3GfLjux"
YOUTUBE_CHANNEL_ID6=  "PLgFrDSKYT2CORbuWeU34siSu2VDEV369D"
YOUTUBE_CHANNEL_ID7=  "PLgFrDSKYT2CMx-0_tGK2_DQAfnJK77omh"
YOUTUBE_CHANNEL_ID8=  "PLgFrDSKYT2CN4ZMJOLb6-cSKJ2jZSOdEA"
YOUTUBE_CHANNEL_ID9=  "PLgFrDSKYT2CMDrgkNMEVLXR-Ja9-wXkeF"
YOUTUBE_CHANNEL_ID10= "PLgFrDSKYT2CPIDYEph5rFJvxc_7sK5Tqt"
YOUTUBE_CHANNEL_ID11= "PLgFrDSKYT2CNRnJ9_UqKCWv89f_ChOJSF"
YOUTUBE_CHANNEL_ID12= "PLgFrDSKYT2CPf8TwTqmNu_LRta1y9Q9sJ"



# Ponto de Entrada
def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
    addDir(title = "Arrocha",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon )
    addDir(title = "Axe",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon )
    addDir(title = "Brega/Classicos",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail = icon )
    addDir(title = "Eletronico/Party",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID4+"/",thumbnail = icon )
    addDir(title = "Forro",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID5+"/",thumbnail = icon )
    addDir(title = "Funk / Funk Melody e Funk Carioca",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID6+"/",thumbnail = icon )
    addDir(title = "Gospel/Sacra/Crista",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID7+"/",thumbnail = icon )
    addDir(title = "Hip-Hop",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID8+"/",thumbnail = icon )
    addDir(title = "MPB",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID9+"/",thumbnail = icon )
    addDir(title = "Pagode",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID10+"/",thumbnail = icon )
    addDir(title = "Parodia",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID11+"/",thumbnail = icon )
    addDir(title = "Pop",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID12+"/",thumbnail = icon )
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
    


