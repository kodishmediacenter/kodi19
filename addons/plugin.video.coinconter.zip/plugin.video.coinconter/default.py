# -*- coding: utf-8 -*-

import xbmc
import xbmcvfs
import xbmcgui

dialog = xbmcgui.Dialog()

# Solicitar a quantidade de moedas e converter para inteiro
moedas5 = int(dialog.input('Digite quantidade de Moedas 0,05   (por unidade)', '', type=xbmcgui.INPUT_ALPHANUM))
moedas10 = int(dialog.input('Digite quantidade de Moedas 0,10  (por unidade)', '', type=xbmcgui.INPUT_ALPHANUM))
moedas25 = int(dialog.input('Digite quantidade de Moedas 0,25  (por unidade)', '', type=xbmcgui.INPUT_ALPHANUM))
moedas50 = int(dialog.input('Digite quantidade de Moedas 0,50  (por unidade)', '', type=xbmcgui.INPUT_ALPHANUM))
moedas100 = int(dialog.input('Digite quantidade de Moedas 1,00 (por unidade)', '', type=xbmcgui.INPUT_ALPHANUM))

# Calcular o total em centavos
total_centavos = (moedas5 * 5) + (moedas10 * 10) + (moedas25 * 25) + (moedas50 * 50) + (moedas100 * 100)

# Converter o total para reais
total_reais = total_centavos / 100.0

# Exibir o resultado
dialog.textviewer('Total em R$', f'{total_reais:.2f}')
