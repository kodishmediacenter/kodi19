# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.casteloratimbum'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')



icon =  "https://yt3.ggpht.com/-4ek1aHeRexQ/AAAAAAAAAAI/AAAAAAAAAAA/Y0j_7WLsx24/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"
YOUTUBE_CHANNEL_ID  = "PL2-ncQsY8gXXoogNdIizbOHl29MMjon5j"

def addDir(title, url , thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
if __name__ == '__main__':
        
    addDir(title = "Castelo Rá-Tim-Bum!",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID+"/",thumbnail = icon)
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
		
		
