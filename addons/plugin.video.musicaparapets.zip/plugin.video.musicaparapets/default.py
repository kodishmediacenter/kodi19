
# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.musicaparapets'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')





def addDir(title,url,icons):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} ) 
    liz.setArt({'thumb':icons,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
if __name__ == '__main__':
    YOUTUBE_CHANNEL_ID1 = "channel/UC0cHVVyWnIR9LDj51PISjTw/playlists"
    icon1 = "https://yt3.ggpht.com/a/AGF-l7-rrUl8uSryrZr3uhqwU__0W1JcqTD4sL7r_Q=s288-c-k-c0xffffffff-no-rj-mo"
    YOUTUBE_CHANNEL_ID2 = "channel/UCseGhLmIfr9TSxw9xRafo1Q"
    icon2 = "https://yt3.ggpht.com/a/AGF-l7_XQQQOIFOW9PUs4a7K2gHZkfSuBzqNgXtqNQ=s288-c-k-c0xffffffff-no-rj-mo"
    YOUTUBE_CHANNEL_ID3 = "channel/UCwc9u8hPZaDX3WZeaQHC1_A"
    icon3 = "https://yt3.ggpht.com/a/AGF-l7_znAnboJn1LFAZK1O51e8KQRSfp_1r5xueyg=s288-c-k-c0xffffffff-no-rj-mo"
    YOUTUBE_CHANNEL_ID4 = "channel/UCIkbOuoU-_B16_1BS-2uvRQ"
    icon4 = "https://yt3.ggpht.com/a/AGF-l7-dsiNQMwKr0iaEv2jxOGOhhgeUJVGAFK8TWA=s288-c-k-c0xffffffff-no-rj-mo"
    YOUTUBE_CHANNEL_ID5 ="channel/UCVqytdh_eTzWlh1K8Yst_rg"
    icon5 = "https://yt3.ggpht.com/a/AGF-l79iLDuUGeXcW38mbzxqcpPTD9xuXJEqcLuLPw=s288-c-k-c0xffffffff-no-rj-mo"
    YOUTUBE_CHANNEL_ID6 ="channel/UC2BDs0pu-C1A4POY0g9rZxw"
    icon6 ="https://yt3.ggpht.com/a/AGF-l7-K92BtdpMgtuOZd2mWkuRNhVbdKcGdtc7FBg=s288-c-k-c0xffffffff-no-rj-mo"
    YOUTUBE_CHANNEL_ID7 ="channel/UC_MuyKN5moN4uXrGJ557sGQ"
    icon7 = "https://yt3.ggpht.com/a/AGF-l7-njYOJJLRHpHiidd_CYedzEglJR2gWZZR9Jw=s288-c-k-c0xffffffff-no-rj-mo"

    
   
    

    addDir(title="PetTunes - Music For Pets",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",icons=icon1)
    addDir(title="Acalme seu gato - música para gatos"            , url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",icons=icon2)
    addDir(title="Relax Your Dog - Calming Music and TV"          ,url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",icons=icon3)
    #addDir(title="Musica Relaxante para Animais de Estimação"          ,url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",icons=icon4)
    addDir(title="Calm Your Dog - Relaxing Music and TV for Dogs" ,url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",icons=icon5)
    addDir(title="Relax My Dog - Música Relaxante para Cães"          ,url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID6+"/",icons=icon6)
    #addDir(title="Sons da Natureza"          ,url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID7+"/",icons=icon7)
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
