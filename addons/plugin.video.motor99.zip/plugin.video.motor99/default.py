# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.video.motor99'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')



YOUTUBE_CHANNEL_ID1 = "Formula1"
YOUTUBE_CHANNEL_ID2 = "wrc"
YOUTUBE_CHANNEL_ID3 = "laf1es"
YOUTUBE_CHANNEL_ID4 = "MonsterWorldRally"
YOUTUBE_CHANNEL_ID5 = "gt1world"
YOUTUBE_CHANNEL_ID6 = "FIAFormulaE"
YOUTUBE_CHANNEL_ID7 = "DTMinternational"
YOUTUBE_CHANNEL_ID8 = "TheFIAWTCC"
YOUTUBE_CHANNEL_ID9 = "MotoGP"
YOUTUBE_CHANNEL_ID10 = "dakar"
YOUTUBE_CHANNEL_ID11 = "UCUX0ttGpAdrHCIaYFNX7CqA"
YOUTUBE_CHANNEL_ID12 = "UCCKEHIkEVrivZFffRWkE37w"
YOUTUBE_CHANNEL_ID13 = "BestMotorcycleVideos"
YOUTUBE_CHANNEL_ID14 = "UC0mJA1lqKjB4Qaaa2PNf0zg"
YOUTUBE_CHANNEL_ID15 = "f1infoyt"
YOUTUBE_CHANNEL_ID16 = "indycars"
YOUTUBE_CHANNEL_ID17 = "UCpazTQzUIYdxb8xJ7l58r6g"


def addDir(title, url, thumbnail,fanart,folder):
    fan = fanart
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':fan})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
   addDir(title="Noticias F1",url='plugin://plugin.video.youtube/search/?q=noticias formula 1 español',thumbnail="https://1.bp.blogspot.com/-MH37ucAOJy4/X3wOURR6t9I/AAAAAAABnY0/BiHnrp-ahxMW9vY87zRNfVWIqLOqdlaNACLcBGAsYHQ/s600/NOTICIASF1.png",fanart="https://i.redd.it/w4bbg7esagk11.jpg",folder=True )
   addDir(title="Resumen Carreras F1",url='plugin://plugin.video.youtube/search/?q=premio f1 2020: mejores momentos',thumbnail="https://1.bp.blogspot.com/-fJvjSbsZnRc/X4s8k49KR8I/AAAAAAABneo/U2vMVGUSGZoAZyN_gY177Qp9YmJTTCUPQCLcBGAsYHQ/s320/resumen%2Bcarreras.png",fanart="https://imgresizer.eurosport.com/unsafe/1200x0/filters:format(jpeg)/origin-imgresizer.eurosport.com/2017/09/17/2169149-45340390-2560-1440.jpg",folder=True )
   addDir(title="Carreras F1",url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID17+"/",thumbnail="https://1.bp.blogspot.com/-sx4GjvElwJM/X5csRPTWoqI/AAAAAAABnk0/ZD8k076T0RADoY8zgJ-z7mBiPDGbAXQlwCLcBGAsYHQ/s600/Logos%2Bplugin%2BMOTOR%2B99%2B%252814%2529.png",fanart="https://i.pinimg.com/originals/57/a8/58/57a85878c354cc61e8c64a2b7c536785.jpg",folder=True )
   addDir(title="F1",url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail="https://1.bp.blogspot.com/-uG07CTmZy34/X481SEqgFDI/AAAAAAABngA/ldno0xLkgI83k9mK8IgrAauc52iwbHY_gCLcBGAsYHQ/s600/f1%2B%25281%2529.png",fanart="https://2.bp.blogspot.com/-ZUKPGAc_AsM/WOIsO_YQfBI/AAAAAAAAbK4/jTR1ONZgLsIk2K0DSdi2eyOE9Yv_Y1LWACLcB/s1600/formula_1_track_aerial_view-wallpaper-1920x1080.jpg",folder=True )
   addDir(title="Documental : La Gran Aventura de la F1",url="plugin://plugin.video.youtube/playlist/PLYXsNr8imJt2NxRyfkt9Mg5fGjDPjsl9n/",fanart="https://wallpaperstock.net/wallpapers/thumbs1/45301hd.jpg",thumbnail="https://1.bp.blogspot.com/-Rck3FuYG8d4/X4rtDnESUbI/AAAAAAABnec/cDEMryGBco8kD6ITi-8235Qto-7t8_04gCLcBGAsYHQ/s320/Logos%2Bplugin%2BMOTOR%2B99.png",folder=True )
   addDir(title="WRC",url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail="https://4.bp.blogspot.com/-0qMIssKqlh8/WOO3cvFrZpI/AAAAAAAAbO0/Lt-xTFuTqdogY1mGx3rKEiJzFIIRMeyDgCLcB/s1600/WRC.png",fanart="https://4.bp.blogspot.com/-A4lo468Vwqg/WOIzy1FwgDI/AAAAAAAAbLY/UAZw9u-Jc2Qc_QuKWoLBnVxWZQ96q3ybQCLcB/s1600/wc1788960.jpg",folder=True )
   addDir(title="SoyMotor",url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail="https://3.bp.blogspot.com/-Vzl_jNdMt7Y/WOO3QX51ClI/AAAAAAAAbOw/pllRmOti9z0bEhflLO5-fOIP9dTVsv1EwCLcB/s1600/soymotor.png",fanart="",folder=True )
   addDir(title="Ken Block",url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID4+"/",thumbnail="https://1.bp.blogspot.com/--iV4JgjfISk/X48zOTskQgI/AAAAAAABnf0/oURAnpnq500EDcR_YGa3iIuq8XX75o0rgCLcBGAsYHQ/s600/Logos%2Bplugin%2BMOTOR%2B99%2B%25281%2529.png",fanart="https://4.bp.blogspot.com/-XqT1MIARctc/XUPexKHngxI/AAAAAAAAy5Q/O1Z6QxhZi8wSuTrhPncTsEzM7IkvfKiEACLcBGAs/s1600/189919.jpg",folder=True )  
   addDir(title="GT4",url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID5+"/",thumbnail="https://1.bp.blogspot.com/-YBUTTKLbJSg/X5CYMHuMa0I/AAAAAAABnh4/GHWlSJJlKwU4mem6PriVTo_979mPoyZaQCLcBGAsYHQ/s600/Logos%2Bplugin%2BMOTOR%2B99%2B%25282%2529.png",fanart="https://4.bp.blogspot.com/-flWb4l6LLIU/WON_X04gBkI/AAAAAAAAbNY/f344C4KEyLYrpxmculHZys-lJfXg3DZCgCLcB/s1600/gt4-series-race-racing-g-t-rally-grand-prix-supercar-0Yjv.jpg",folder=True )
   addDir(title="Formula E",url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID6+"/",thumbnail="https://1.bp.blogspot.com/-XloCjZAgRmc/X5CZai3LgxI/AAAAAAABniA/kN4lGWpVb_E7HyvRcHJPHR_PEuRKIRvWQCLcBGAsYHQ/s600/Logos%2Bplugin%2BMOTOR%2B99%2B%25283%2529.png",fanart="https://1.bp.blogspot.com/-BOrvvzz5beo/WOOBzE-T3sI/AAAAAAAAbNw/HyoEsncQD0MWKBrDhRIPc265yd56NagKACLcB/s1600/ds-virgin-16-17-2.jpg",folder=True )
   addDir(title="DTM",url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID7+"/",thumbnail="https://1.bp.blogspot.com/-PDmaHvOoJpQ/X5CbSZv7l0I/AAAAAAABniU/P5OBw3zd_Q0ms5vbyzrqDc7Kk2990jC6gCLcBGAsYHQ/s600/Logos%2Bplugin%2BMOTOR%2B99%2B%25285%2529.png",fanart="https://1.bp.blogspot.com/-sInGT_rOHV8/WOO97-gS1xI/AAAAAAAAbPg/C0ivz9K5eYsQXdIG1lQALz7u_VgVOZkqgCLcB/s1600/cars_tuning_BMW_M3_DTM_Concept_1920x1200.jpg",folder=True )		
   addDir(title="WTCR",url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID8+"/",thumbnail="https://1.bp.blogspot.com/-8IFtx_rPl58/X5CaYyOER0I/AAAAAAABniI/2ZZyejpD8aYnaOFgVjXZWpnGwyOIMEV6gCLcBGAsYHQ/s600/Logos%2Bplugin%2BMOTOR%2B99%2B%25284%2529.png",fanart="https://1.bp.blogspot.com/-t-rAmPhaRY4/XUMs_5-iiRI/AAAAAAAAys8/39U61XOSEoQC5Tew-LXJEhfTV5O_bxLfgCLcBGAs/s1600/wtcr.jpg",folder=True )	
   addDir(title="MotoGP",url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID9+"/",thumbnail="https://2.bp.blogspot.com/-GEk0m969hdo/WOPDDhYhyXI/AAAAAAAAbP4/Y7wgq239NfsYbzOFd2kNtb5dB1J4sFcUwCLcB/s1600/motogp.png",fanart="https://4.bp.blogspot.com/-aaksYwlqINU/WOPDERTNgWI/AAAAAAAAbP8/pQtxsQ-gUPE4ul2UIdhkKSkqm5BrAauuQCLcB/s1600/malasia-test-motogp-2016.jpg",folder=True )	
   addDir(title="Dakar",url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID10+"/",thumbnail="https://1.bp.blogspot.com/-IGZQC7syhMA/X5GUHnX1fwI/AAAAAAABnio/cKjYHWBMhBswczt-WzdhbzyNdOPVCLZEgCLcBGAsYHQ/s600/Logos%2Bplugin%2BMOTOR%2B99%2B%25286%2529.png",fanart="https://4.bp.blogspot.com/-nz_GKAesNmY/XUP5Zpx6xVI/AAAAAAAAy74/w3na51zCN88G1ZOokfUQ68ruVwt_fVjuwCLcBGAs/s1600/dakar-rally-wallpapers-31001-6043285.jpg",folder=True ) 
   addDir(title="Indycar Series",url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID16+"/",thumbnail="https://1.bp.blogspot.com/-Y9T6Hsr6ReI/X5HW7xz6VaI/AAAAAAABnjw/zPSVEQbkZ_wbFDT7U2M2BDYNvP1b-hM4QCLcBGAsYHQ/s600/Logos%2Bplugin%2BMOTOR%2B99%2B%252813%2529.png",fanart="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRTCej-gkI1HeDap4LEuJrkwVXZlXj8hSsCHA&usqp=CAU",folder=True )	
   addDir(title="IMSA Español",url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID12+"/",thumbnail="https://1.bp.blogspot.com/-nRwyPbSvK0s/X5GUyZRXuII/AAAAAAABniw/Fjxtz8CJHpg1y3IAoiGjPn5MIpLzyiIwgCLcBGAsYHQ/s600/Logos%2Bplugin%2BMOTOR%2B99%2B%25287%2529.png",fanart="https://4.bp.blogspot.com/-x9aW44FkJXo/XUQFD8IO4YI/AAAAAAAAy9g/F6gNAL4C7rollXEr5Tnfw3tvJXMpdi8xACLcBGAs/s1600/08012019_iwsc_roadamerica_preview_1280x626.jpg",folder=True )			
   addDir(title="EnduroLife",url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID13+"/",thumbnail="https://1.bp.blogspot.com/-hXTbkVWh_cE/X5GVXPa2woI/AAAAAAABni4/mhMBcg8zvdcq5qidbk6cAz9n5CIz-qlaQCLcBGAsYHQ/s600/Logos%2Bplugin%2BMOTOR%2B99%2B%25288%2529.png",fanart="https://4.bp.blogspot.com/-ircdChh4D8o/XUQLO4duS2I/AAAAAAAAy90/L4-2_4eZnPwDSBdSBUegFzXq6J7h8xMDgCLcBGAs/s1600/wp1900761.jpg",folder=True )
   addDir(title="Red Bull Motorsport",url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID14+"/",thumbnail="https://1.bp.blogspot.com/-y5NRSkN_ax0/X5GV2jSWEEI/AAAAAAABnjA/I2rC18JOiKMlXZYSogGgWaUQh0gpMSr7gCLcBGAsYHQ/s600/Logos%2Bplugin%2BMOTOR%2B99%2B%25289%2529.png",fanart="https://3.bp.blogspot.com/-qGAANz5BBWo/XUQOm5WjkgI/AAAAAAAAy-A/OBhnxqZ30NgZK7Q4tqomFBr2wlyCWbvoQCLcBGAs/s1600/motoring-collection.jpg",folder=True )		
   addDir(title="MotorLat",url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID11+"/",thumbnail="https://1.bp.blogspot.com/-jmLG9DMyRdM/X5Gh7FS6Z5I/AAAAAAABnjM/94TPZ-iVfuw9Qp2UjluqY2n5KWDwOofRwCLcBGAsYHQ/s600/Logos%2Bplugin%2BMOTOR%2B99%2B%252810%2529.png",fanart="https://i.ytimg.com/vi/uPn5X2jtMy8/maxresdefault.jpg",folder=True )   
   addDir(title="Efeuno",url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID15+"/",thumbnail="https://1.bp.blogspot.com/-vkt91mrtnz4/X5Gr5gs1vlI/AAAAAAABnjY/n94kbGdw4Ts42h-v1uI-KC8gHniVbyayQCLcBGAsYHQ/s600/Logos%2Bplugin%2BMOTOR%2B99%2B%252811%2529.png",fanart="https://i.pinimg.com/originals/7c/3d/a6/7c3da64e529078ce41833dcc7caf717d.jpg",folder=True )            
   addDir(title="Gran Turismo World Tour",url="plugin://plugin.video.youtube/playlist/PLPzH13D_rtcCs7kG9K6X4uEq4RjmBkf34/",thumbnail="https://1.bp.blogspot.com/-YvxWMeKL9AM/X5GwWgF611I/AAAAAAABnjk/eL48KOng3ZklEUW0-GkVaz3PML-EgzfLwCLcBGAsYHQ/s600/Logos%2Bplugin%2BMOTOR%2B99%2B%252812%2529.png",fanart="https://livingplaystation.com/wp-content/uploads/2020/02/Gran-Turismo-Sport-Gran-Turismo-World-Tour-Gran-Turismo-Championship-GTC_SIDNEY_04.jpg",folder=True )             
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
