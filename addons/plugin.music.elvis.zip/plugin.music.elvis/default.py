# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.music.elvis'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID = "PLAl-cwrHd5ao4ILSx3gAZaxWzB2GUZ5jY"
YOUTUBE_CHANNEL_ID2 = "PLAl-cwrHd5arrCsQxiNJc-xhTu44FR9pD"
YOUTUBE_CHANNEL_ID3 = "PLAl-cwrHd5aqzKyvUNPwnJWWie309NMkF"
YOUTUBE_CHANNEL_ID4 = "PLAl-cwrHd5aoRK1pZf5Cp2mzOCVJCp5Rc"


def addDir(title, url):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':ICON,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
if __name__ == '__main__':

    addDir(title = "Golden Elvis Disk 1",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID+"/")
    addDir(title = "Golden Elvis Disk 2",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID2+"/")
    addDir(title = "Golden Elvis Disk 3",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID3+"/",)
    addDir(title = "Golden Elvis Disk 4",url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID4+"/",)
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
