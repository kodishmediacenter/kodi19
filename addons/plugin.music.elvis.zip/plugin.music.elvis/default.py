# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.music.elvis'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "playlist/PLAl-cwrHd5ao4ILSx3gAZaxWzB2GUZ5jY"
icon1 = ICON


YOUTUBE_CHANNEL_ID = "playlist/PLAl-cwrHd5ao4ILSx3gAZaxWzB2GUZ5jY"
YOUTUBE_CHANNEL_ID2 = "playlist/PLAl-cwrHd5arrCsQxiNJc-xhTu44FR9pD"
YOUTUBE_CHANNEL_ID3 = "playlist/PLAl-cwrHd5aqzKyvUNPwnJWWie309NMkF"
YOUTUBE_CHANNEL_ID4 = "playlist/PLAl-cwrHd5aoRK1pZf5Cp2mzOCVJCp5Rc"

def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
   addDir(title = "Elvis Golden Disk Disco 1",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon1,)
   addDir(title = "Elvis Golden Disk Disco 2",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon1,)
   addDir(title = "Elvis Golden Disk Disco 3",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail = icon1,)
   addDir(title = "Elvis Golden Disk Disco 4",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",thumbnail = icon1,)
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
