# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin,xbmcvfs 
import requests,json,os
# Plugin Info

ADDON_ID      = 'plugin.music.petterewendy'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')


def files(url):
    dialog = xbmcgui.Dialog()
    fn = dialog.browseSingle(1, 'Peter e Wendy', 'music', '', False, False, url)
    fn2 = fn.replace('&amp%3b','&').replace('https','http')
    
    f = os.path.join(xbmcvfs.translatePath("special://home/addons/plugin.music.petterewendy/load.m3u"))
    file = open(f,"w") 
    file.write(fn2)
    
    g = os.path.join(xbmcvfs.translatePath("special://home/addons/plugin.music.petterewendy/history.m3u"))
    file2 = open(g,"a") 
    file2.write(fn2)
    
    file.close()
    file2.close()
    
    xbmc.Player().play(f)
    xbmc.Player().play(f)
    
def menu():
    dialog = xbmcgui.Dialog()
    
    link = dialog.select('Peter e Wendy', ['Disney in Concert','Tributo a Marilia Mendonça','Feminejo','Novidades do Site','Pedidos','The Mask Singer Brasil','Espera','Folhas ao Vento','Hidden','Lady Butterfly','Acustico Internacional','Acustico Nacional','Balada',
    'Beatles','Blues','Flashback','Festa Junina','Roberto Carlos','Rock','Reggae','Infantil','-','Todas Categorias do Site'])
    link2 = int(link)
    
    links = ['https://peterewendy.com.br/Genero/Mp3/***DISNEY_IN_CONCERT/',
    'https://peterewendy.com.br/Genero/Mp3/***TRIBUTO_MARILIA_MENDONCA/',
    'https://peterewendy.com.br/Genero/Mp3/**FEMINEJO/','https://peterewendy.com.br/Genero/Mp3/**NOVIDADES_NO_SITE/',
    'https://peterewendy.com.br/Genero/Mp3/**PEDIDOS/','https://peterewendy.com.br/Genero/Mp3/**THE_MASKED_SINGER_BR/',
    'https://peterewendy.com.br/Genero/Mp3/*ESPERA/','https://peterewendy.com.br/Genero/Mp3/*FOLHAS_AO_VENTO/',
    'https://peterewendy.com.br/Genero/Mp3/*HIDDEN/','https://peterewendy.com.br/Genero/Mp3/*LADY_BUTTERFLY/',
    'https://peterewendy.com.br/Genero/Mp3/ACUSTICO_(INTERNACIONAL)/','https://peterewendy.com.br/Genero/Mp3/ACUSTICO_(NACIONAL)/',
    'https://peterewendy.com.br/Genero/Mp3/BALADA/','https://peterewendy.com.br/Genero/Mp3/BEATLES/'
    ,'https://peterewendy.com.br/Genero/Mp3/BLUES/','https://peterewendy.com.br/Genero/Mp3/FLASHBACK/',
    'https://peterewendy.com.br/Genero/Mp3/FESTA_JUNINA/','https://peterewendy.com.br/Genero/Mp3/ROBERTO_CARLOS/',
    'https://peterewendy.com.br/Genero/Mp3/ROCK/','https://peterewendy.com.br/Genero/Mp3/REGGAE/','https://peterewendy.com.br/Genero/Mp3/INFANTIL/','','https://peterewendy.com.br/Genero/Mp3/']
    
    geturl = links[link2]
    files(geturl)
    
    
    
    




menu()
