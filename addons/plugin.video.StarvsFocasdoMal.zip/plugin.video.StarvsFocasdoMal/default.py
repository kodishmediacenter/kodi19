# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.video.StarvsFocasdoMal'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1= "playlist/PLfp1JBJztVEExHclODttQJVO80k22Zsyr"
YOUTUBE_CHANNEL_ID2= "playlist/PLfp1JBJztVEFlc6Heu_gQk1JjIBZWByzo"
YOUTUBE_CHANNEL_ID3= "playlist/PLfp1JBJztVEEAaWz5oEKWr7O5nvocqzO9"
YOUTUBE_CHANNEL_ID4= "playlist/PLfp1JBJztVEHaY1C90qWT7n0ZRezG6VCR"

icon1 = "https://yt3.ggpht.com/a/AATXAJyUEjlbN57-V-qqPxjqSqgyKD8OFVm2e3nFTTgLgQ=s256-c-k-c0x00ffffff-no-rj"
def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
   addDir(title = "Star vs Forcas do Mal Epsodios Dublados 1º Temporada",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon1,)
   addDir(title = "Star vs Forcas do Mal Epsodios Dublados 2º Temporada",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon1,)
   addDir(title = "Star vs Forcas do Mal Epsodios Dublados 3º Temporada",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail = icon1,)
   addDir(title = "Star vs Forcas do Mal Epsodios Dublados 4º Temporada",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",thumbnail = icon1,)
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
