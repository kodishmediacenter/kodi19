import xbmc
import xbmcgui
import xbmcvfs
import urllib.request
import os

def download_arquivo(url, destino):
    """
    Faz download de um arquivo no Kodi
    :param url: URL do arquivo
    :param destino: caminho final (ex: special://temp/video.mp4)
    """

    # Converte special:// para caminho real
    destino_real = xbmcvfs.translatePath(destino)
    pasta = os.path.dirname(destino_real)

    # Cria pasta se não existir
    if not xbmcvfs.exists(pasta):
        xbmcvfs.mkdirs(pasta)

    dialog = xbmcgui.DialogProgress()
    dialog.create("Download", "Baixando arquivo...")

    try:
        with urllib.request.urlopen(url) as response:
            tamanho_total = int(response.headers.get("Content-Length", 0))
            baixado = 0
            bloco = 1024 * 32

            with open(destino_real, "wb") as arquivo:
                while True:
                    if dialog.iscanceled():
                        arquivo.close()
                        xbmcvfs.delete(destino_real)
                        dialog.close()
                        return False

                    buffer = response.read(bloco)
                    if not buffer:
                        break

                    arquivo.write(buffer)
                    baixado += len(buffer)

                    if tamanho_total > 0:
                        progresso = int((baixado * 100) / tamanho_total)
                        dialog.update(progresso, f"{progresso}% concluído")

        dialog.close()
        xbmcgui.Dialog().notification(
            "Download concluído",
            os.path.basename(destino_real),
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
        return True

    except Exception as e:
        dialog.close()
        xbmcgui.Dialog().notification(
            "Erro no download",
            str(e),
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )
        return False

url = "https://raw.githubusercontent.com/kodishmediacenter/kodishgen/refs/heads/main/kodish/KDS001.jpg"
destino = "special://home/media/backgrounds/KDS001.jpg"

download_arquivo(url, destino)
